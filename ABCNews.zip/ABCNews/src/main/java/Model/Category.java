package Model;

public class Category {
    private String id;        // VARCHAR(10) - là mã luôn: GD, TT, PL...
    private String name;      // NVARCHAR(50)

    public Category() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}