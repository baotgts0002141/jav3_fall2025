package Controller;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/newsletter")  // ← ĐÚNG URL EM ĐANG GỌI
public class NewsletterServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        String message;

        if (email == null || email.trim().isEmpty()) {
            message = "Vui lòng nhập email!";
        } else {
            try {
         
                message = "Đăng ký thành công! Bạn sẽ nhận tin mới nhất từ chúng tôi!";
            } catch (Exception e) {
                message = "Email đã tồn tại hoặc có lỗi xảy ra!";
            }
        }

        request.setAttribute("message", message);
        request.setAttribute("email", email);
        request.getRequestDispatcher("/view/guest/newsletter.jsp").forward(request, response);
    }

    // Thêm doGet để hiển thị form (nếu cần)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/view/guest/newsletter.jsp").forward(request, response);
    }
}