package Controller;

import Dao.CategoryDAO;
import Model.Category;
import Model.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/category")
public class AdminCategoryServlet extends HttpServlet {

    private final CategoryDAO categoryDAO = new CategoryDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        checkAdmin(request, response);
        request.setCharacterEncoding("UTF-8"); // FIX LỖI FONT 100%

        String action = request.getParameter("action");
        String id = request.getParameter("id");

        try {
            if ("edit".equals(action) && id != null) {
                Category cate = categoryDAO.findById(id);
                request.setAttribute("cate", cate);
            } else if ("delete".equals(action) && id != null) {
                categoryDAO.delete(id);
                // Sau khi xóa → redirect để reload danh sách
                response.sendRedirect(request.getContextPath() + "/admin/category");
                return;
            }

            List<Category> list = categoryDAO.getAll();
            request.setAttribute("listCate", list);
            request.setAttribute("contentPage", "/view/admin/category-manager.jsp");
            request.getRequestDispatcher("/layout/admin-main.jsp").forward(request, response);

        } catch (Exception e) {
        e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/admin/category");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        checkAdmin(request, response);
        request.setCharacterEncoding("UTF-8"); // FIX LỖI FONT 100%

        String action = request.getParameter("action");
        String id = request.getParameter("id");
        String name = request.getParameter("name");

        try {
            if ("insert".equals(action)) {
                Category c = new Category();
                c.setId(id);     // mã loại tin: GD, TT, PL...
                c.setName(name);
                categoryDAO.insert(c);
            } 
            else if ("update".equals(action)) {
                Category c = new Category();
                c.setId(id);
                c.setName(name);
                categoryDAO.update(c);
            }

            response.sendRedirect(request.getContextPath() + "/admin/category");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/admin/category?error=1");
        }
    }

    private void checkAdmin(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (user == null || !user.isRole()) {
            response.sendRedirect(request.getContextPath() + "/login");
        }
    }
}