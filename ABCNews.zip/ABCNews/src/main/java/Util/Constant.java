package Util;

public class Constant {
    public static final String UPLOAD_DIRECTORY = "uploads/news";  // ĐÚNG YÊU CẦU ĐỀ BÀI!!!
    public static final String DEFAULT_FILENAME = "default.jpg";
    public static final long MAX_FILE_SIZE = 10 * 1024 * 1024;     // 10MB
    public static final long MAX_REQUEST_SIZE = 50 * 1024 * 1024; // 50MB
}