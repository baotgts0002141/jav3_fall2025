package Util;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UploadUtil {

    private static final String UPLOAD_DIR = ":/UploadsNews/news";

    public static Map<String, String> processUpload(String fieldName, HttpServletRequest request) {
        Map<String, String> map = new HashMap<>();
        try {
            request.setCharacterEncoding("UTF-8");

            File uploadDir = new File(UPLOAD_DIR);
            if (!uploadDir.exists()) uploadDir.mkdirs();

            DiskFileItemFactory factory = new DiskFileItemFactory();
            factory.setSizeThreshold(3 * 1024 * 1024);
            factory.setRepository(uploadDir);

            ServletFileUpload upload = new ServletFileUpload(factory);
            upload.setFileSizeMax(10 * 1024 * 1024);
            upload.setSizeMax(50 * 1024 * 1024);
            upload.setHeaderEncoding("UTF-8");

            List<FileItem> items = upload.parseRequest(request);

            for (FileItem item : items) {
                if (item.isFormField()) {
                    map.put(item.getFieldName(), item.getString("UTF-8"));
                } else if (fieldName.equals(item.getFieldName()) && item.getSize() > 0) {
                    String originalName = item.getName();
                    String ext = "";
                    int i = originalName.lastIndexOf('.');
                    if (i > 0) ext = originalName.substring(i);

                    String fileName = System.currentTimeMillis() + "_" + Math.abs(originalName.hashCode()) + ext;
                    File uploadedFile = new File(uploadDir, fileName);
                    item.write(uploadedFile);

                    map.put(fieldName, fileName);
                    System.out.println("UPLOAD THÀNH CÔNG: " + uploadedFile.getAbsolutePath());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }

    public static boolean deleteOldImage(String oldImageName) {
        if (oldImageName == null || oldImageName.trim().isEmpty() || "default.jpg".equals(oldImageName)) return false;
        try {
            File oldFile = new File(UPLOAD_DIR, oldImageName);
            if (oldFile.exists()) return oldFile.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
