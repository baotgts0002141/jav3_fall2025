package Dao;

import Util.Jdbc;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NewsletterDAO {

    public void insert(String email) throws Exception {
        String sql = "IF NOT EXISTS (SELECT 1 FROM Newsletters WHERE Email = ?) INSERT INTO Newsletters (Email, Enabled) VALUES (?, 1)";
        try (Connection conn = Jdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, email);
            ps.executeUpdate();
        }
    }

    public List<String> getAllEnabledEmails() throws Exception {
        List<String> list = new ArrayList<>();
        String sql = "SELECT Email FROM Newsletters WHERE Enabled = 1";
        try (Connection conn = Jdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(rs.getString("Email"));
            }
        }
        return list;
    }

    // CRUD cho admin
    public List<String> getAllEmails() throws Exception {
        List<String> list = new ArrayList<>();
        String sql = "SELECT Email, Enabled FROM Newsletters ORDER BY Enabled DESC";
        try (Connection conn = Jdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(rs.getString("Email"));
            }
        }
        return list;
    }

    public void setEnabled(String email, boolean enabled) throws Exception {
        String sql = "UPDATE Newsletters SET Enabled = ? WHERE Email = ?";
        try (Connection conn = Jdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBoolean(1, enabled);
            ps.setString(2, email);
            ps.executeUpdate();
        }
    }

    public void delete(String email) throws Exception {
        String sql = "DELETE FROM Newsletters WHERE Email = ?";
        try (Connection conn = Jdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.executeUpdate();
        }
    }
}