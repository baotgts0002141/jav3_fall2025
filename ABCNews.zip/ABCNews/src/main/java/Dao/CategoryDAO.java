package Dao;

import Model.Category;
import Util.Jdbc;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoryDAO {

    // LẤY TẤT CẢ LOẠI TIN - FIX LỖI "Id" vs "ID"
    public List<Category> getAll() throws Exception {
        List<Category> list = new ArrayList<>();
        String sql = "SELECT Id, Name FROM Categories ORDER BY Id";  // RÕ RÀNG
        try (Connection conn = Jdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
             
            while (rs.next()) {
                Category c = new Category();
                // DÙNG CẢ 2 CÁCH ĐỂ CHẮC CHẮN KHÔNG LỖI
                String id = rs.getString("Id");
                if (id == null) id = rs.getString("ID"); // SQL Server đôi khi trả về ID
                c.setId(id);
                c.setName(rs.getString("Name"));
                list.add(c);
            }
        }
        return list;
    }

    // TÌM THEO ID (String) - DÙNG CHO GUEST + ADMIN
    public Category findById(String id) throws Exception {
        String sql = "SELECT Id, Name FROM Categories WHERE Id = ?";
        try (Connection conn = Jdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Category c = new Category();
                    String foundId = rs.getString("Id");
                    if (foundId == null) foundId = rs.getString("ID");
                    c.setId(foundId);
                    c.setName(rs.getString("Name"));
                    return c;
                }
            }
        }
        return null;
    }

    // THÊM MỚI
    public void insert(Category c) throws Exception {
        String sql = "INSERT INTO Categories (Id, Name) VALUES (?, ?)";
        try (Connection conn = Jdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getId());
            ps.setString(2, c.getName());
            ps.executeUpdate();
        }
    }

    // CẬP NHẬT
    public void update(Category c) throws Exception {
        String sql = "UPDATE Categories SET Name = ? WHERE Id = ?";
        try (Connection conn = Jdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getName());
            ps.setString(2, c.getId());
            ps.executeUpdate();
        }
    }

    // XÓA
    public void delete(String id) throws Exception {
        String sql = "DELETE FROM Categories WHERE Id = ?";
        try (Connection conn = Jdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            ps.executeUpdate();
        }
    }
}