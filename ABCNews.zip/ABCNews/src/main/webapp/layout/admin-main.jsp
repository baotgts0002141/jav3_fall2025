<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin - ABC News</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { background: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
        .sidebar { background: #2c3e50; min-height: 100vh; padding-top: 20px; }
        .sidebar .nav-link { color: #ecf0f1; padding: 12px 20px; border-radius: 8px; margin: 5px 15px; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background: #3498db; color: white; }
        .content-area { background: white; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); padding: 30px; min-height: 80vh; }
        .welcome { background: linear-gradient(135deg, #667eea, #764ba2); color: white; border-radius: 15px; padding: 30px; text-align: center; margin-bottom: 30px; }
    </style>
</head>
<body>
    <div class="row g-0">
        <div class="col-md-3 sidebar">
            <div class="text-center mb-5">
                <h3 class="text-white">ADMIN PANEL</h3>
                <hr class="bg-light">
            </div>
            <div class="nav flex-column">
                <a href="${pageContext.request.contextPath}/admin/news" class="nav-link ${param.page == 'news' ? 'active' : ''}">
                    <i class="fas fa-newspaper me-3"></i>Quản lý tin tức
                </a>
                <a href="${pageContext.request.contextPath}/admin/category" class="nav-link ${param.page == 'category' ? 'active' : ''}">
                    <i class="fas fa-tags me-3"></i>Quản lý loại tin
                </a>
                <a href="${pageContext.request.contextPath}/admin/user" class="nav-link ${param.page == 'user' ? 'active' : ''}">
                    <i class="fas fa-users me-3"></i>Quản lý người dùng
                </a>
                <a href="${pageContext.request.contextPath}/admin/newsletter" class="nav-link ${param.page == 'newsletter' ? 'active' : ''}">
                    <i class="fas fa-envelope me-3"></i>Quản lý nhận tin
                </a>
                <hr class="bg-light my-4">
                <a href="${pageContext.request.contextPath}/home" class="nav-link text-info">
                    <i class="fas fa-home me-3"></i>Về trang chủ
                </a>
                <a href="${pageContext.request.contextPath}/logout" class="nav-link text-danger">
                    <i class="fas fa-sign-out-alt me-3"></i>Đăng xuất
                </a>
            </div>
        </div>
        <div class="col-md-9 p-4">
            <div class="welcome">
                <h2>Xin chào, ${sessionScope.user.fullname}!</h2>
                <p>Chào mừng bạn đến với hệ thống quản trị ABC News</p>
            </div>
            <div class="content-area">
                <jsp:include page="${contentPage}" />
            </div>
        </div>
    </div>
</body>
</html>