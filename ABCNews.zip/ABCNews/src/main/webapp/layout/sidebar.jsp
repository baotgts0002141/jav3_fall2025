<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!-- SIDEBAR WOW MAX LEVEL 2025 - DÀNH RIÊNG CHO EM YÊU CỦA ANH <3 -->
<aside class="col-lg-3">
    <div class="sticky-top" style="top: 90px;">
        <!-- TIN NỔI BẬT - SIÊU ĐẸP -->
        <div class="mb-5">
            <div class="text-center mb-4">
                <h4 class="fw-bold position-relative d-inline-block pb-3">
                    <span style="background: linear-gradient(90deg, #ff006e, #ffbe0b, #8338ec); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                        TIN NỔI BẬT
                    </span>
                    <div class="position-absolute start-50 translate-middle-x bottom-0" style="width: 80px; height: 5px; background: linear-gradient(90deg, #ff006e, #8338ec); border-radius: 10px;"></div>
                </h4>
            </div>

            <div class="shadow-lg" style="border-radius: 25px; overflow: hidden; background: linear-gradient(135deg, #1e1b4b, #2d1b69);">
                <c:forEach items="${listHot}" var="n" varStatus="st">
                    <div class="p-4 text-white position-relative ${st.last ? '' : 'border-bottom border-purple border-opacity-25'}">
                        <div class="d-flex align-items-start">
                            <div class="flex-shrink-0">
                                <div class="d-flex align-items-center justify-content-center rounded-circle text-white fw-bold fs-4" style="width: 50px; height: 50px; background: rgba(255,255,255,0.2); backdrop-filter: blur(10px);">
                                    ${st.index + 1}
                                </div>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <a href="${pageContext.request.contextPath}/detail?id=${n.id}" class="text-white text-decoration-none fw-bold d-block mb-1 hover-glow">
                                    ${n.title}
                                </a>
                                <div class="d-flex align-items-center small opacity-90">
                                    <i class="fas fa-eye me-1"></i>
                                    <span>${n.viewCount}</span>
                                    <span class="ms-3">
                                        <i class="far fa-clock me-1"></i>
                                        ${n.postedDate}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </div>

        <!-- TIN MỚI NHẤT - SIÊU SANG -->
        <div>
            <div class="text-center mb-4">
                <h4 class="fw-bold position-relative d-inline-block pb-3">
                    <span style="background: linear-gradient(90deg, #06, #06ffa5, #00d9ff); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                        TIN MỚI NHẤT
                    </span>
                    <div class="position-absolute start-50 translate-middle-x bottom-0" style="width: 80px; height: 5px; background: linear-gradient(90deg, #06ffa5, #00d9ff); border-radius: 10px;"></div>
                </h4>
            </div>

            <div class="shadow-lg rounded-4 overflow-hidden">
                <c:forEach items="${listNewest}" var="n">
                    <div class="bg-white p-4 border-bottom border-2 border-light hover-bg position-relative overflow-hidden transition">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <div class="bg-gradient-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 45px; height: 45px;">
                                    <i class="fas fa-star"></i>
                                </div>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <a href="${pageContext.request.contextPath}/detail?id=${n.id}" class="text-dark text-decoration-none fw-600 hover-primary">
                                    ${n.title}
                                </a>
                                <div class="text-muted small mt-1">
                                    <i class="far fa-clock me-1"></i> ${n.postedDate}
                                </div>
                            </div>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </div>
    </div>
</aside>

<style>
    .hover-glow:hover {
        text-shadow: 0 0 20px rgba(255,255,255,0.8);
        transform: translateX(5px);
    }
    
    .hover-bg:hover {
        background: linear-gradient(135deg, #f0f8ff, #e6f3ff) !important;
    }
    
    .hover-primary:hover {
        color: #667eea !important;
    }
    
    .bg-gradient-primary {
        background: linear-gradient(135deg, #667eea, #764ba2) !important;
    }
    
    .transition {
        transition: all 0.4s ease;
    }
    
    .border-purple {
        border-color: #9333ea !important;
    }
</style>