<%@page contentType="text/html" pageEncoding="UTF-8"%>
<footer class="bg-dark text-white py-5 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <h4>ABC News</h4>
                <p>Website tin tức được xây dựng bởi sinh viên FPT Polytechnic</p>
                <p>© 2025 ABC News. All rights reserved.</p>
            </div>
            <div class="col-md-4">
                <h5>Đăng ký nhận tin mới</h5>
                <form action="${pageContext.request.contextPath}/newsletter" method="post" class="d-flex">
                    <input type="email" name="email" class="form-control me-2" placeholder="Nhập email của bạn" required>
                    <button type="submit" class="btn btn-danger">Đăng ký</button>
                </form>
                <small class="text-muted d-block mt-2">Chúng tôi cam kết không spam!</small>
            </div>
        </div>
    </div>
</footer>