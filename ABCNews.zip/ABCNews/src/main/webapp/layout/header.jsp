<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<header class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold fs-3 text-white" href="${pageContext.request.contextPath}/home">
            ABC News
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link text-white" href="${pageContext.request.contextPath}/home">Trang chủ</a>
                </li>
                <c:forEach items="${listCate}" var="c">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="${pageContext.request.contextPath}/category?id=${c.id}">${c.name}</a>
                    </li>
                </c:forEach>
            </ul>

            <div class="d-flex align-items-center gap-3">
                <!-- Nếu chưa đăng nhập -->
                <c:if test="${sessionScope.user == null}">
                    <a href="${pageContext.request.contextPath}/login" class="btn btn-outline-light">Đăng nhập</a>
                </c:if>

                <!-- Nếu đã đăng nhập -->
                <c:if test="${sessionScope.user != null}">
                    <span class="text-white fw-bold">Xin chào, ${sessionScope.user.fullname}</span>

                    <!-- PHÓNG VIÊN: hiện 2 nút lớn luôn -->
                    <c:if test="${!sessionScope.user.role}">
                        <a href="${pageContext.request.contextPath}/my-news?action=edit" 
                           class="btn btn-success btn-lg shadow">
                            Viết bài mới
                        </a>
                        <a href="${pageContext.request.contextPath}/my-news" 
                           class="btn btn-outline-warning">
                            Quản lý tin của tôi
                        </a>
                    </c:if>

                    <!-- ADMIN: chỉ hiện nút Quản trị -->
                    <c:if test="${sessionScope.user.role}">
                        <a href="${pageContext.request.contextPath}/admin/news" 
                           class="btn btn-warning">
                            Quản trị hệ thống
                        </a>
                    </c:if>

                    <a href="${pageContext.request.contextPath}/logout" 
                       class="btn btn-outline-danger">Đăng xuất</a>
                </c:if>
            </div>
        </div>
    </div>
</header>