<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<div class="container-fluid py-4">
    <h2 class="text-primary fw-bold mb-4">Quản lý loại tin</h2>

    <div class="row g-4">
        <!-- Form thêm/sửa -->
        <div class="col-lg-5">
            <div class="card shadow border-0">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">${empty cate ? 'Thêm loại tin mới' : 'Sửa loại tin'}</h5>
                </div>
                <div class="card-body">
                    <form action="${pageContext.request.contextPath}/admin/category" method="post">
                        <input type="hidden" name="action" value="${empty cate ? 'insert' : 'update'}">
                        
                        <c:if test="${not empty cate}">
                            <input type="hidden" name="id" value="${cate.id}">
                        </c:if>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Mã loại tin</label>
                            <input type="text" name="id" class="form-control" 
                                   value="${cate.id}" 
                                   ${not empty cate ? 'readonly' : ''} 
                                   placeholder="VD: GD, SK, VH" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Tên loại tin</label>
                            <input type="text" name="name" class="form-control" 
                                   value="${cate.name}" placeholder="VD: Giáo dục" required>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-success px-4">
                                ${empty cate ? 'Thêm mới' : 'Cập nhật'}
                            </button>
                            <a href="${pageContext.request.contextPath}/admin/category" 
                               class="btn btn-secondary px-4">Hủy</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Danh sách -->
        <div class="col-lg-7">
            <div class="card shadow border-0">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Danh sách loại tin</h5>
                </div>
                <div class="card-body p-0">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Mã</th>
                                <th>Tên loại tin</th>
                                <th class="text-center">Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach items="${listCate}" var="c">
                            <tr>
                                <td><strong class="text-primary">${c.id}</strong></td>
                                <td>${c.name}</td>
                                <td class="text-center">
                                    <a href="${pageContext.request.contextPath}/admin/category?action=edit&id=${c.id}" 
                                       class="btn btn-warning btn-sm">Sửa</a>
                                    <a href="${pageContext.request.contextPath}/admin/category?action=delete&id=${c.id}" 
                                       class="btn btn-danger btn-sm"
                                       onclick="return confirm('Xóa loại tin \"${c.name}\" này?')">Xóa</a>
                                </td>
                            </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>