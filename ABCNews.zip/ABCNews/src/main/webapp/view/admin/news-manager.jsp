<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<h2 class="text-primary fw-bold mb-4">Quản lý tất cả tin tức</h2>

<table class="table table-hover">
    <thead class="table-dark">
        <tr>
            <th>ID</th>
            <th>Tiêu đề</th>
            <th>Tác giả</th>
            <th>Loại</th>
            <th>Lượt xem</th>
            <th>Ngày đăng</th>
            <th>Trang chủ</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <c:forEach items="${listNews}" var="n">
            <tr>
                <td>${n.id}</td>
                <td><a href="${pageContext.request.contextPath}/detail?id=${n.id}" target="_blank">${n.title}</a></td>
                <td>${n.author}</td>
                <td>${n.categoryId}</td>
                <td>${n.viewCount}</td>
                <td>${n.postedDate}</td>
                <td class="text-center">
                    <c:if test="${n.home}">
                        <span class="badge bg-success">Có</span>
                    </c:if>
                    <c:if test="${not n.home}">
                        <span class="badge bg-secondary">Không</span>
                    </c:if>
                </td>
                <td>
                    <a href="${pageContext.request.contextPath}/detail?id=${n.id}" target="_blank" class="btn btn-info btn-sm">Xem</a>
                </td>
            </tr>
        </c:forEach>
    </tbody>
</table>