<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<h2 class="text-primary fw-bold mb-4">Quản lý đăng ký nhận tin</h2>

<p class="text-muted">Tổng số lượng: ${listEmail.size()} email đang hoạt động</p>

<table class="table table-striped">
    <thead class="table-dark">
        <tr>
            <th>STT</th>
            <th>Email</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <c:forEach items="${listEmail}" var="email" varStatus="st">
            <tr>
                <td>${st.index + 1}</td>
                <td>${email}</td>
                <td>
                    <a href="newsletter?action=delete&id=${email}" class="btn btn-danger btn-sm"
                       onclick="return confirm('Xóa email này khỏi danh sách nhận tin?')">Xóa</a>
                </td>
            </tr>
        </c:forEach>
    </tbody>
</table>