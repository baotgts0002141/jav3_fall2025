<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<h2 class="text-primary fw-bold mb-4">Quản lý người dùng</h2>

<table class="table table-striped">
    <thead class="table-dark">
        <tr>
            <th>ID</th>
            <th>Họ tên</th>
            <th>Email</th>
            <th>Vai trò</th>
        </tr>
    </thead>
    <tbody>
        <c:forEach items="${listUser}" var="u">
            <tr>
                <td>${u.id}</td>
                <td>${u.fullname}</td>
                <td>${u.email}</td>
                <td>${u.role ? 'Quản trị viên' : 'Phóng viên'}</td>
            </tr>
        </c:forEach>
    </tbody>
</table>