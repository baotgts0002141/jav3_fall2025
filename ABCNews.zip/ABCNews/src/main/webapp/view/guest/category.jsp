<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:set var="now" value="<%= System.currentTimeMillis() %>" />

<div class="container py-4">
    <h3 class="mb-4 fw-bold text-primary">${currentCateName}</h3>

    <div class="row">
        <c:forEach items="${listNews}" var="n">
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <c:choose>
                        <c:when test="${not empty n.image}">
                            <img src="${pageContext.request.contextPath}/uploads/news/${n.image}?v=${now}"
                                 class="card-img-top" style="height: 200px; object-fit: cover;"
                                 onerror="this.src='${pageContext.request.contextPath}/uploads/news/default.jpg?v=${now}'">
                        </c:when>
                        <c:otherwise>
                            <img src="${pageContext.request.contextPath}/uploads/news/default.jpg?v=${now}"
                                 class="card-img-top" style="height: 200px; object-fit: cover;">
                        </c:otherwise>
                    </c:choose>
                    <div class="card-body">
                        <h5 class="card-title">
                            <a href="${pageContext.request.contextPath}/detail?id=${n.id}" 
                               class="text-decoration-none">
                                ${n.title}
                            </a>
                        </h5>
                        <small class="text-muted">
                            <fmt:formatDate value="${n.postedDate}" pattern="dd/MM/yyyy"/>
                        </small>
                    </div>
                </div>
            </div>
        </c:forEach>
    </div>

    <c:if test="${empty listNews}">
        <p class="text-muted">Chưa có tin tức trong chuyên mục này</p>
    </c:if>
</div>