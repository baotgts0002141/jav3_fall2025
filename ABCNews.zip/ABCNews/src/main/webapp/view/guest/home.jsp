<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:set var="now" value="<%= System.currentTimeMillis() %>" />

<div class="container py-4">
    <h2 class="text-center mb-5 fw-bold text-primary">TIN TỨC NỔI BẬT</h2>

    <div class="row">
        <c:forEach items="${listHome}" var="n">
            <div class="col-md-4 mb-4">
                <div class="card h-100 shadow-sm">
                    <c:choose>
                        <c:when test="${not empty n.image}">
                            <img src="${pageContext.request.contextPath}/uploads/news/${n.image}?v=${now}"
                                 class="card-img-top" style="height: 220px; object-fit: cover;"
                                 onerror="this.src='${pageContext.request.contextPath}/uploads/news/default.jpg?v=${now}'">
                        </c:when>
                        <c:otherwise>
                            <img src="${pageContext.request.contextPath}/uploads/news/default.jpg?v=${now}"
                                 class="card-img-top" style="height: 220px; object-fit: cover;">
                        </c:otherwise>
                    </c:choose>
                    <div class="card-body d-flex flex-column">
                        <span class="badge bg-danger mb-2">Nổi bật</span>
                        <h5 class="card-title">
                            <a href="${pageContext.request.contextPath}/detail?id=${n.id}" 
                               class="text-decoration-none text-dark">
                                ${n.title}
                            </a>
                        </h5>
                        <small class="text-muted mt-auto">
                            <fmt:formatDate value="${n.postedDate}" pattern="dd/MM/yyyy"/> - 
                            ${n.viewCount} lượt xem
                        </small>
                    </div>
                </div>
            </div>
        </c:forEach>
    </div>

    <c:if test="${empty listHome}">
        <div class="text-center py-5">
            <p class="text-muted">Chưa có tin tức nổi bật</p>
        </div>
    </c:if>
</div>