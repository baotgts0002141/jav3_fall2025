<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:set var="now" value="<%= System.currentTimeMillis() %>" />

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">

            <!-- Badge tin nổi bật -->
            <c:if test="${news.home}">
                <div class="text-center mb-4">
                    <span class="badge bg-danger fs-4 px-5 py-3">TIN NỔI BẬT</span>
                </div>
            </c:if>

            <!-- Tiêu đề -->
            <h1 class="display-4 fw-bold text-center mb-4">${news.title}</h1>

            <!-- Thông tin bài viết -->
            <div class="text-center text-muted mb-5 fs-5">
                <i class="fas fa-user me-2"></i> ${news.author} • 
                <i class="fas fa-calendar me-2"></i> 
                <fmt:formatDate value="${news.postedDate}" pattern="dd/MM/yyyy HH:mm"/> • 
                <i class="fas fa-eye me-2"></i> 
                <span class="text-danger fw-bold">${news.viewCount}</span> lượt xem
            </div>

            <!-- Ảnh đại diện -->
            <c:if test="${not empty news.image}">
                <img src="${pageContext.request.contextPath}/uploads/news/${news.image}?v=${now}"
                     class="img-fluid rounded-4 shadow-lg mb-5 w-100"
                     style="max-height: 600px; object-fit: cover;"
                     onerror="this.src='${pageContext.request.contextPath}/uploads/news/default.jpg?v=${now}'"
                     alt="${news.title}">
            </c:if>

            <!-- Nội dung -->
            <div class="lead fs-4 lh-lg text-justify mb-5">
                ${news.content}
            </div>

            <!-- PHẦN TIN LIÊN QUAN – BẮT BUỘC THEO ĐỀ BÀI -->
            <c:if test="${not empty listSameCate}">
                <hr class="my-5">
                <h3 class="fw-bold text-primary mb-4">
                    <i class="fas fa-newspaper me-2"></i>TIN LIÊN QUAN
                </h3>
                <div class="row g-4">
                    <c:forEach items="${listSameCate}" var="related" begin="0" end="5">
                        <c:if test="${related.id != news.id}">
                            <div class="col-md-6">
                                <div class="d-flex align-items-center bg-light p-3 rounded-4 shadow-sm hover-effect">
                                    <c:choose>
                                        <c:when test="${not empty related.image}">
                                            <img src="${pageContext.request.contextPath}/uploads/news/${related.image}?v=${now}"
                                                 class="rounded me-3" width="110" height="80" style="object-fit: cover;"
                                                 onerror="this.src='${pageContext.request.contextPath}/uploads/news/default.jpg?v=${now}'">
                                        </c:when>
                                        <c:otherwise>
                                            <img src="${pageContext.request.contextPath}/uploads/news/default.jpg?v=${now}"
                                                 class="rounded me-3" width="110" height="80" style="object-fit: cover;">
                                        </c:otherwise>
                                    </c:choose>
                                    <div>
                                        <h6 class="mb-1">
                                            <a href="${pageContext.request.contextPath}/detail?id=${related.id}"
                                               class="text-decoration-none text-dark fw-600 hover-primary">
                                                ${related.title}
                                            </a>
                                        </h6>
                                        <small class="text-muted">
                                            <fmt:formatDate value="${related.postedDate}" pattern="dd/MM/yyyy"/>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </c:if>
                    </c:forEach>
                </div>
            </c:if>

            <!-- Nút quay lại -->
            <div class="text-center mt-5">
                <a href="javascript:history.back()" class="btn btn-outline-primary btn-lg px-5">
                    Quay lại
                </a>
            </div>
        </div>
    </div>
</div>

<style>
    .hover-effect:hover { background-color: #f8f9fa !important; transform: translateY(-3px); transition: all 0.3s; }
    .hover-primary:hover { color: #0d6efd !important; }
</style>