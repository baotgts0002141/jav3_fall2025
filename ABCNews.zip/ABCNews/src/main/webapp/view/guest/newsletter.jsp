<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Đăng ký nhận tin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-body p-5">
                    <h2 class="text-center mb-4">Đăng ký nhận tin tức mới nhất</h2>
                    
                    <form action="${pageContext.request.contextPath}/newsletter" method="post">
                        <div class="mb-3">
                            <input type="email" name="email" class="form-control form-control-lg" 
                                   placeholder="nhapemail@abc.com" required 
                                   value="${email}">
                        </div>
                        <button type="submit" class="btn btn-primary btn-lg w-100">
                            Đăng ký ngay
                        </button>
                    </form>

                    <c:if test="${not empty message}">
                        <div class="alert ${message.contains('thành công') ? 'alert-success' : 'alert-danger'} mt-4">
                            ${message}
                        </div>
                    </c:if>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>