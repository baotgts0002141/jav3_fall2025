<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<%-- PHÁ CACHE ẢNH - BẮT BUỘC PHẢI CÓ --%>
<c:set var="now" value="<%= System.currentTimeMillis() %>" />

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-11">
            <div class="card shadow-lg border-0" style="border-radius: 25px; overflow: hidden;">
                <div class="card-header text-white text-center py-5"
                     style="background: linear-gradient(135deg, #667eea, #764ba2);">
                    <h1 class="fw-bold mb-0 display-4">
                        <i class="fas fa-pen-fancy me-3"></i>
                        ${news == null ? 'VIẾT BÀI BÁO MỚI' : 'CHỈNH SỬA BÀI BÁO'}
                    </h1>
                </div>

                <div class="card-body p-5">
                    <form action="my-news" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="${news.id}">
                        <input type="hidden" name="oldImage" value="${news.image}">

                        <!-- Tiêu đề -->
                        <div class="mb-4">
                            <label class="form-label fw-bold fs-4 text-primary">Tiêu đề bài báo</label>
                            <input type="text" name="title" class="form-control form-control-lg rounded-3 shadow-sm"
                                   value="${news.title}" placeholder="Nhập tiêu đề thật hấp dẫn nha..." required>
                        </div>

                        <!-- Nội dung -->
                        <div class="mb-4">
                            <label class="form-label fw-bold fs-4 text-primary">Nội dung bài báo</label>
                            <textarea name="content" class="form-control rounded-3 shadow-sm" rows="15"
                                      placeholder="Viết nội dung chi tiết, càng hay càng tốt nha..." required>${news.content}</textarea>
                        </div>

                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label class="form-label fw-bold fs-4 text-primary">Chuyên mục</label>
                                <select name="categoryId" class="form-select form-select-lg rounded-3 shadow-sm" required>
                                    <c:forEach items="${listCate}" var="c">
                                        <option value="${c.id}" ${c.id == news.categoryId ? 'selected' : ''}>${c.name}</option>
                                    </c:forEach>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-bold fs-4 text-primary">Hiển thị trang chủ</label>
                                <div class="form-check form-switch mt-3">
                                    <input class="form-check-input" type="checkbox" name="home" id="homeSwitch"
                                           style="width: 80px; height: 40px;" ${news.home ? 'checked' : ''}>
                                    <label class="form-check-label fs-5 fw-bold text-success" for="homeSwitch">
                                        Bật để hiện trang chủ
                                    </label>
                                </div>
                            </div>
                        </div>

                        <!-- Ảnh đại diện -->
                        <div class="mb-5">
                            <label class="form-label fw-bold fs-4 text-primary">Ảnh đại diện bài viết</label>

                            <!-- ẢNH HIỆN TẠI – ĐÃ FIX CACHE -->
                            <c:if test="${not empty news.image}">
                                <div class="mb-4 text-center bg-light p-4 rounded-4 shadow">
                                    <p class="text-success fw-bold mb-3 fs-5">
                                        Ảnh hiện tại của bài viết:
                                    </p>
                                    <img src="${pageContext.request.contextPath}/uploads/news/${news.image}?v=${now}"
                                         class="img-fluid rounded-4 shadow-lg border border-5 border-white"
                                         style="max-height: 480px; width: 100%; object-fit: cover;"
                                         alt="Ảnh hiện tại"
                                         onerror="this.src='${pageContext.request.contextPath}/uploads/news/default.jpg?v=${now}'">
                                </div>
                            </c:if>

                            <input type="file" name="image" class="form-control form-control-lg rounded-3 shadow-sm"
                                   accept="image/*">
                            <div class="form-text text-muted mt-2">
                                Để trống nếu không muốn thay đổi ảnh • Tối đa 10MB • Định dạng: JPG, PNG, GIF
                            </div>
                        </div>

                        <div class="text-center mt-5">
                            <button type="submit" class="btn btn-success btn-lg px-5 me-4 shadow-lg"
                                    style="border-radius: 50px; font-size: 1.3rem;">
                                ${news == null ? 'ĐĂNG BÀI NGAY' : 'CẬP NHẬT BÀI'}
                            </button>
                            <a href="my-news" class="btn btn-danger btn-lg px-5 shadow-lg"
                               style="border-radius: 50px; font-size: 1.3rem;">
                                Hủy bỏ
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>