<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<div class="d-flex justify-content-between align-items-center mb-5">
    <h2 class="fw-bold text-primary">
        <i class="fas fa-edit me-3"></i>Tin tức của tôi
    </h2>
    <a href="my-news?action=edit" class="btn btn-success btn-lg shadow">
        <i class="fas fa-plus me-2"></i>Viết tin mới
    </a>
</div>

<c:if test="${not empty param.success}">
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>Tin đã được lưu thành công!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
</c:if>

<div class="table-responsive">
    <table class="table table-hover align-middle">
        <thead class="table-primary">
            <tr>
                <th>STT</th>
                <th width="80">Ảnh</th>  <!-- THÊM CỘT ẢNH -->
                <th>Tiêu đề</th>
                <th>Loại tin</th>
                <th>Lượt xem</th>
                <th>Ngày đăng</th>
                <th>Trang chủ</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach items="${listNews}" var="n" varStatus="st">
                <tr>
                    <td>${st.index + 1}</td>
                    
                    <!-- CỘT ẢNH MỚI – ĐẸP NHƯ BÁO CHÍNH THỐNG -->
					<td>
					    <c:choose>
					        <c:when test="${not empty n.image}">
					            <img src="${pageContext.request.contextPath}/uploads/news/${n.image}"
					                 class="rounded" width="70" height="50" style="object-fit: cover;"
					                 alt="Ảnh tin"
					                 onerror="this.src='${pageContext.request.contextPath}/uploads/news/default.jpg'">
					        </c:when>
					        <c:otherwise>
					            <img src="${pageContext.request.contextPath}/uploads/news/default.jpg"
					                 class="rounded" width="70" height="50" style="object-fit: cover;" alt="Default">
					        </c:otherwise>
					    </c:choose>
					</td>

                    <td class="fw-600">
                        <a href="${pageContext.request.contextPath}/detail?id=${n.id}" 
                           class="text-decoration-none text-primary" target="_blank">
                           ${n.title}
                        </a>
                    </td>
                    <td>${n.categoryId}</td>
                    <td><span class="badge bg-info">${n.viewCount}</span></td>
                    <td>${n.postedDate}</td>
                    <td>
                        <c:choose>
                            <c:when test="${n.home}">
                                <span class="badge bg-success">Có</span>
                            </c:when>
                            <c:otherwise>
                                <span class="badge bg-secondary">Không</span>
                            </c:otherwise>
                        </c:choose>
                    </td>
                    <td>
                        <a href="my-news?action=edit&id=${n.id}" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit"></i> Sửa
                        </a>
                        <a href="my-news?action=delete&id=${n.id}" class="btn btn-danger btn-sm"
                           onclick="return confirm('Xóa tin này vĩnh viễn?')">
                            <i class="fas fa-trash"></i> Xóa
                        </a>
                    </td>
                </tr>
            </c:forEach>
        </tbody>
    </table>
</div>

<c:if test="${empty listNews}">
    <div class="text-center py-5">
        <p class="text-muted fs-3">Chưa có tin nào. Hãy <a href="my-news?action=edit" class="text-primary">viết tin mới</a> ngay!</p>
    </div>
</c:if>