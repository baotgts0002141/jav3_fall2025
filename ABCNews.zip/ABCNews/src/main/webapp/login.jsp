<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Đăng nhập • ABC News</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        * { font-family: 'Poppins', sans-serif; }
        
        body {
            background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
            background-size: 400% 400%;
            animation: gradient 15s ease infinite;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        @keyframes gradient {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        .login-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            width: 400px;
            backdrop-filter: blur(10px);
        }
        
        .login-header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 40px 30px;
            text-align: center;
            position: relative;
        }
        
        .login-header::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: url('https://images.unsplash.com/photo-1504711434969-e338861bb9f7?w=1920') center/cover;
            opacity: 0.1;
        }
        
        .login-header h1 {
            font-weight: 700;
            font-size: 2.8rem;
            margin: 0;
            text-shadow: 0 3px 10px rgba(0,0,0,0.4);
        }
        
        .login-header p {
            margin: 10px 0 0;
            font-size: 1.1rem;
            opacity: 0.9;
        }
        
        .login-body {
            padding: 40px;
        }
        
        .form-control {
            height: 55px;
            border-radius: 15px;
            border: 2px solid #f0f0f0;
            padding-left: 55px;
            font-size: 1.1rem;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.25);
        }
        
        .input-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #667eea;
            font-size: 1.3rem;
            z-index: 5;
        }
        
        .input-group {
            position: relative;
        }
        
        .btn-login {
            height: 55px;
            border-radius: 15px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border: none;
            font-size: 1.2rem;
            font-weight: 600;
            letter-spacing: 1px;
            transition: all 0.4s;
        }
        
        .btn-login:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(102, 126, 234, 0.4);
        }
        
        .logo-circle {
            width: 100px;
            height: 100px;
            background: white;
            border-radius: 50%;
            margin: 0 auto -50px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            position: relative;
            z-index: 10;
        }
        
        .logo-circle i {
            font-size: 3.5rem;
            color: #667eea;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="logo-circle">
                <i class="fas fa-newspaper"></i>
            </div>
            <h1>ABC News</h1>
            <p>Hệ thống quản trị nội dung</p>
        </div>
        
        <div class="login-body">
            <c:if test="${not empty error}">
                <div class="alert alert-danger text-center py-3 rounded-3">
                    <i class="fas fa-exclamation-triangle me-2"></i>${error}
                </div>
            </c:if>

            <form action="login" method="post">
                <div class="mb-4 input-group">
                    <span class="input-icon"><i class="fas fa-user"></i></span>
                    <input type="text" class="form-control" name="id" placeholder="Tên đăng nhập" required autofocus>
                </div>

                <div class="mb-4 input-group">
                    <span class="input-icon"><i class="fas fa-lock"></i></span>
                    <input type="password" class="form-control" name="pass" placeholder="Mật khẩu" required>
                </div>

                <button type="submit" class="btn btn-login w-100 text-white mb-3">
                    <i class="fas fa-sign-in-alt me-2"></i>ĐĂNG NHẬP NGAY
                </button>
            </form>

            <div class="text-center">
                <a href="${pageContext.request.contextPath}/home" class="text-decoration-none text-muted">
                    <i class="fas fa-home me-2"></i>Quay về trang chủ
                </a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>