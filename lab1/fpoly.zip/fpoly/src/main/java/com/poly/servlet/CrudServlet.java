package com.poly.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {
	    "/crud/create",
	    "/crud/update",
	    "/crud/delete",
	    "/crud/edit"
	})
public class CrudServlet extends HttpServlet {
	@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Lấy URI để xác định người dùng gọi URL nào
        String uri = req.getRequestURI();
        
        // Cài đặt nội dung và mã hóa
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");
        
        PrintWriter out = resp.getWriter();
        
        // Xuất thông báo tương ứng 
        if (uri.contains("create")) {
            out.println("<h1>Thông báo: Bạn muốn TẠO MỚI</h1>");
        } else if (uri.contains("update")) {
            out.println("<h1>Thông báo: Bạn muốn CẬP NHẬT</h1>");
        } else if (uri.contains("delete")) {
            out.println("<h1>Thông báo: Bạn muốn XOÁ</h1>");
        } else if (uri.contains("edit")) {
            // Đối với /crud/edit/2024, bạn có thể lấy số 2024 nếu muốn
            out.println("<h1>Thông báo: Bạn muốn CHỈNH SỬA (EDIT)</h1>");
        }

        out.close();
    }
}
