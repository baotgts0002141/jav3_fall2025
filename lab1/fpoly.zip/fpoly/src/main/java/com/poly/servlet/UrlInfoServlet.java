package com.poly.servlet;

import java.io.IOException;
import java.io.PrintWriter;

@jakarta.servlet.annotation.WebServlet("/info/*")
public class UrlInfoServlet extends jakarta.servlet.http.HttpServlet {
	@Override
    protected void doGet(jakarta.servlet.http.HttpServletRequest req, jakarta.servlet.http.HttpServletResponse resp)
            throws jakarta.servlet.ServletException, IOException {
        
        // Cài đặt kiểu nội dung và mã hóa ký tự cho
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");

        // Lấy đối tượng PrintWriter để ghi nội dung HTML
        PrintWriter out = resp.getWriter();

        // Lấy 7 thông tin theo yêu cầu
        String url = req.getRequestURL().toString(); // 
        String uri = req.getRequestURI(); // 
        String queryString = req.getQueryString(); // 
        String servletPath = req.getServletPath(); // 
        String contextPath = req.getContextPath(); // 
        String pathInfo = req.getPathInfo(); // 
        String method = req.getMethod(); // 

        // Xuất ra trình duyệt
        out.println("<!DOCTYPE html><html><head><title>URL Info</title></head><body>");
        out.println("<h1>Thông tin URL</h1>");
        out.println("<p><strong>1. URL:</strong> " + url + "</p>");
        out.println("<p><strong>2. URI:</strong> " + uri + "</p>");
        out.println("<p><strong>3. QueryString:</strong> " + (queryString != null ? queryString : "Không có") + "</p>");
        out.println("<p><strong>4. ServletPath:</strong> " + servletPath + "</p>");
        out.println("<p><strong>5. ContextPath:</strong> " + contextPath + "</p>");
        out.println("<p><strong>6. PathInfo:</strong> " + (pathInfo != null ? pathInfo : "Không có") + "</p>");
        out.println("<p><strong>7. Method:</strong> " + method + "</p>");
        out.println("</body></html>");
    }
}
