package lab2.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	req.setAttribute("message", "Welcome FPT POLYTECHNIC");
	Map<String, Object> map = new HashMap<>();
	map.put("fullname", "Hồ Thanh An Đông");
	map.put("gender", "Male");
	map.put("country", "Viet Nam");
	
	//Đưa map vào req
	req.setAttribute("info", map);
	
	req.getRequestDispatcher("/page1.jsp").forward(req, resp);
}
}
