package lab2.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/form/update")
public class FormServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        Map<String, Object> map = new HashMap<>();
        map.put("fullname", "Nguyễn Văn Tèo");
        map.put("gender", true);
        map.put("country", "VN");

        req.setAttribute("user", map);
        req.setAttribute("editabled", true); // true = readonly + disable Create

        req.getRequestDispatcher("/form.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String fullname = req.getParameter("fullname");
        String gender = req.getParameter("gender");
        String country = req.getParameter("country");

        System.out.println("Fullname: " + fullname);
        System.out.println("Gender: " + gender);
        System.out.println("Country: " + country);

        // Truyền lại dữ liệu người dùng vừa nhập
        Map<String, Object> map = new HashMap<>();
        map.put("fullname", fullname);
        map.put("gender", Boolean.parseBoolean(gender));
        map.put("country", country);

        req.setAttribute("user", map);
        req.setAttribute("editabled", false); // cho phép sửa

        req.getRequestDispatcher("/form.jsp").forward(req, resp);
    }
}
