<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jstl/fmt_rt" prefix="fmt"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Danh sách quốc gia</title>
</head>
<body>

<jsp:include page="menu.jsp"></jsp:include>
	 <ul>
			<li>Name: ${item.name}</li>
			<li>Price:
			<fmt:formatNumber value="${item.price}" pattern="#,###.00"/>
			</li>
			<li>Date:
			<fmt:formatDate value="${item.date}" pattern="MMM dd, yyyy"/>
			</li>
	</ul>
</body>
</html>
