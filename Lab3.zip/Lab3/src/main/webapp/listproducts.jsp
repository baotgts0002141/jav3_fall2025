<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Danh sách sản phẩm</title>
    <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/style.css">
</head>
<body>

    <jsp:include page="menu.jsp"></jsp:include>

    <!-- Thông báo thêm vào giỏ hàng -->
    <c:if test="${not empty sessionScope.message}">
        <div class="notification">
            ${sessionScope.message}
        </div>
        <c:remove var="message" scope="session" />
    </c:if>

    <center>
        <h2>Danh sách sản phẩm</h2>
        <br>

        <table>
            <thead>
                <tr>
                    <th>Tên sản phẩm</th>
                    <th>Hình ảnh</th>
                    <th>Giá</th>
                    <th>Khuyến mãi</th>
                    <th>Chi tiết</th>
                    <th>Thêm giỏ hàng</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="item" items="${items}">
                    <tr>
                        <!-- Tên sản phẩm -->
                        <td>${item.name}</td>

                        <!-- Hình ảnh (click vào ảnh → xem chi tiết, đã có context path) -->
                        <td>
                            <a href="${pageContext.request.contextPath}/viewitem?id=${item.name}">
                                <img src="${pageContext.request.contextPath}/img/${item.image}"
                                     alt="${item.name}"
                                     width="100"
                                     style="border-radius:8px; transition:0.3s; cursor:pointer;"
                                     onmouseover="this.style.transform='scale(1.08)'; this.style.boxShadow='0 8px 16px rgba(0,0,0,0.2)';"
                                     onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='none';">
                            </a>
                        </td>

                        <!-- Giá gốc -->
                        <td>
                            <fmt:formatNumber value="${item.price}" type="currency" currencySymbol="VNĐ" />
                        </td>

                        <!-- % khuyến mãi -->
                        <td>
                            <fmt:formatNumber value="${item.discount * 100}" type="number" />%
                        </td>

                        <!-- Link chi tiết -->
                        <td>
                            <a href="${pageContext.request.contextPath}/viewitem?id=${item.name}"
                               style="color:#2196F3; font-weight:bold;">
                               Chi tiết
                            </a>
                        </td>

                        <!-- Form thêm vào giỏ hàng -->
                        <td>
                            <form action="${pageContext.request.contextPath}/addtocart" method="post">
                                <input type="hidden" name="id" value="${item.name}">
                                <button type="submit"
                                        style="background:#4CAF50; color:white; padding:8px 16px; border:none; border-radius:5px; cursor:pointer;">
                                    Thêm vào giỏ
                                </button>
                            </form>
                        </td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>

        <hr />
    </center>

</body>
</html>