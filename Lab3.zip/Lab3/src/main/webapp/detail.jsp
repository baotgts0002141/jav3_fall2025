<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>
        <c:choose>
            <c:when test="${not empty selectedItem}">${selectedItem.name} - Chi tiết sản phẩm</c:when>
            <c:otherwise>Chi tiết sản phẩm</c:otherwise>
        </c:choose>
    </title>
    <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/style-detail.css">
</head>
<body>

    <jsp:include page="menu.jsp"></jsp:include>

    <!-- Thông báo thêm vào giỏ (nếu có) -->
    <c:if test="${not empty sessionScope.message}">
        <div class="notification" style="text-align:center; margin:15px auto; max-width:600px;">
            ${sessionScope.message}
        </div>
        <c:remove var="message" scope="session" />
    </c:if>

    <div class="container">

        <!-- Có sản phẩm -->
        <c:if test="${not empty selectedItem}">
            <div class="card">
                <!-- Hình ảnh -->
                <img class="card-img" 
                     src="${pageContext.request.contextPath}/img/${selectedItem.image}" 
                     alt="${selectedItem.name}">

                <div class="card-content">
                    <h2 class="card-title">${selectedItem.name}</h2>

                    <!-- Giảm giá -->
                    <c:if test="${selectedItem.discount > 0}">
                        <div class="card-discount">
                            Giảm: <fmt:formatNumber value="${selectedItem.discount * 100}" type="number" />%
                        </div>
                    </c:if>

                    <!-- Giá -->
                    <div class="card-price">
                        <c:choose>
                            <c:when test="${selectedItem.discount > 0}">
                                <strike style="color:#999; margin-right:15px;">
                                    <fmt:formatNumber value="${selectedItem.price}" type="currency" currencySymbol="VNĐ"/>
                                </strike>
                                <span style="color:#e74c3c; font-size:28px; font-weight:bold;">
                                    <fmt:formatNumber value="${selectedItem.price * (1 - selectedItem.discount)}" 
                                                      type="currency" currencySymbol="VNĐ"/>
                                </span>
                            </c:when>
                            <c:otherwise>
                                <span style="color:#27ae60; font-size:28px; font-weight:bold;">
                                    <fmt:formatNumber value="${selectedItem.price}" type="currency" currencySymbol="VNĐ"/>
                                </span>
                            </c:otherwise>
                        </c:choose>
                    </div>

                    <!-- Mô tả -->
                    <div class="card-description">
                        <p>Mô tả: Đây là sản phẩm <strong>${selectedItem.name}</strong> – 
                           chất lượng cao cấp, thiết kế hiện đại, phù hợp cho mọi nhu cầu sử dụng hàng ngày và làm quà tặng ý nghĩa.</p>
                    </div>

                    <!-- Nút hành động -->
                    <div class="card-action">
                        <a href="${pageContext.request.contextPath}/bai5list" 
                           style="background:#3498db; padding:12px 30px; margin-right:15px;">
                           Trở về danh sách
                        </a>
                        <form action="${pageContext.request.contextPath}/addtocart" method="post" style="display:inline;">
                            <input type="hidden" name="id" value="${selectedItem.name}">
                            <button type="submit" 
                                    style="background:#e67e22; color:white; padding:12px 30px; border:none; border-radius:5px; cursor:pointer; font-weight:bold;">
                                Thêm vào giỏ hàng
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </c:if>

        <!-- Không tìm thấy sản phẩm -->
        <c:if test="${empty selectedItem}">
            <div class="not-found" style="text-align:center; padding:50px; font-size:22px;">
                <p style="color:#e74c3c;">Sản phẩm không tồn tại hoặc đã bị xóa!</p>
                <br>
                <a href="${pageContext.request.contextPath}/bai5list" style="color:#3498db; font-size:18px;">
                    Quay lại danh sách sản phẩm
                </a>
            </div>
        </c:if>

    </div>

</body>
</html>