<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Danh sách quốc gia</title>
</head>
<body>
<jsp:include page="menu.jsp"></jsp:include>
    <h2>Chọn quốc gia:</h2>
    <form action="#">
        <select name="country">
            <c:forEach var="ct" items="${Countries}">
                <option value="${ct.id}">${ct.name}</option>
            </c:forEach>
        </select>
        <input type="submit" value="Gửi">
    </form>
</body>
</html>
