<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Giỏ hàng</title>
    <link rel="stylesheet" type="text/css" href="style-cart.css">
</head>
<body>

    <jsp:include page="menu.jsp"></jsp:include>

    <h2 class="cart-title">Giỏ hàng của bạn</h2>

    <!-- Thông báo nếu cần (tùy chọn thêm) -->
    <c:if test="${not empty sessionScope.message}">
        <div class="notification">
            ${sessionScope.message}
        </div>
        <c:remove var="message" scope="session"/>
    </c:if>

    <c:choose>
        <c:when test="${empty sessionScope.cart}">
            <p style="text-align:center; font-size:18px; color:#666; margin-top:50px;">
                Giỏ hàng hiện đang trống.
            </p>
            <p style="text-align:center;">
                <a href="${pageContext.request.contextPath}/bai5list" style="color:#4CAF50; font-weight:bold;">
                    Tiếp tục mua sắm
                </a>
            </p>
        </c:when>

        <c:otherwise>
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Tên sản phẩm</th>
                        <th>Hình ảnh</th>
                        <th>Đơn giá</th>
                        <th>Giảm</th>
                        <th>Số lượng</th>
                        <th>Thành tiền</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>

                    <!-- Khởi tạo tổng tiền = 0 -->
                    <c:set var="total" value="${0}" scope="page" />

                    <c:forEach var="ci" items="${sessionScope.cart}" varStatus="vs">
                        <tr>
                            <td>${vs.count}</td>
                            <td>${ci.item.name}</td>
                            <td>
                                <img src="${pageContext.request.contextPath}/img/${ci.item.image}"
                                     alt="${ci.item.name}" width="80" style="border-radius:5px;" />
                            </td>
                            <td>
                                <fmt:formatNumber value="${ci.item.price}" type="currency" currencySymbol="VNĐ" />
                            </td>
                            <td>
                                <fmt:formatNumber value="${ci.item.discount * 100}" type="number" />%
                            </td>
                            <td>${ci.quantity}</td>
                            <td>
                                <fmt:formatNumber value="${ci.item.price * (1 - ci.item.discount) * ci.quantity}"
                                                  type="currency" currencySymbol="VNĐ" />
                            </td>
                            <td>
                                <!-- Form cập nhật giỏ hàng -->
                                <form action="${pageContext.request.contextPath}/updatecart" method="post"
                                      style="display:inline;">
                                    <input type="hidden" name="name" value="${ci.item.name}">
                                    <button type="submit" name="action" value="increase"
                                            style="background:#4CAF50;">+</button>
                                    <button type="submit" name="action" value="decrease"
                                            style="background:#ff9800;">-</button>
                                    <button type="submit" name="action" value="remove"
                                            style="background:#f44336;">Xóa</button>
                                </form>
                            </td>
                        </tr>

                        <!-- Cộng dồn tổng tiền -->
                        <c:set var="total"
                               value="${total + (ci.item.price * (1 - ci.item.discount) * ci.quantity)}" />
                    </c:forEach>
                </tbody>
            </table>

            <!-- Hiển thị tổng tiền cuối cùng (chỉ tính 1 lần) -->
            <div class="cart-total">
                <h3>Tổng thanh toán</h3>
                <p style="font-size:24px; color:#e74c3c; font-weight:bold;">
                    <fmt:formatNumber value="${total}" type="currency" currencySymbol="VNĐ" />
                </p>
            </div>

        </c:otherwise>
    </c:choose>

</body>
</html>