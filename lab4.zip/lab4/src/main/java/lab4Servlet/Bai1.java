package lab4Servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/account/login")
public class Bai1 extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	req.setAttribute("message", "Enter username and password");
	req.getRequestDispatcher("/login.jsp").forward(req, resp);
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		if(username.equalsIgnoreCase("FPT") && password.equals("poly")) {
		req.setAttribute("message", "Login successfully");
		} else {
		req.setAttribute("message", "Invalid username or password");
		}
		req.getRequestDispatcher("/menu.jsp").forward(req, resp);
	}

}
