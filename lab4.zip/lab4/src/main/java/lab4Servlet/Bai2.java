package lab4Servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet({"/calculate","/calculate/add", "/calculate/sub"})
public class Bai2 extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	req.setAttribute("message", "Nhập số và chọn phép tính");
	req.getRequestDispatcher("/maytinh.jsp").forward(req, resp);
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String a = req.getParameter("a");
		String b = req.getParameter("b");
		String path = req.getServletPath();
		if(path.endsWith("/add")) {
		double c = Double.valueOf(a) + Double.valueOf(b);
		req.setAttribute("message", a + " + " + b + " = " + c);
		} else {
		double c = Double.valueOf(a) - Double.valueOf(b);
		req.setAttribute("message", a + " - " + b + " = " + c);
		}
		req.getRequestDispatcher("/maytinh.jsp").forward(req, resp);
	}
}
