<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Kết quả đăng ký</title>
</head>
<body>
<h1>Kết quả đăng ký</h1>

<p><strong>Tên đăng nhập:</strong> ${fullname}</p>
<p><strong>Giới tính:</strong>
    <c:choose>
        <c:when test="${gender == 'True'}">Nam</c:when>
        <c:otherwise>Nữ</c:otherwise>
    </c:choose>
</p>
<p><strong>Đã có gia đình:</strong> ${married}</p>
<p><strong>Quốc gia:</strong> ${country}</p>

<p><strong>Sở thích:</strong>
<c:if test="${not empty hobbies}">
    <ul>
        <c:forEach var="h" items="${hobbies}">
            <li>${h}</li>
        </c:forEach>
    </ul>
</c:if>
<c:if test="${empty hobbies}">
    Không có sở thích nào được chọn.
</c:if>
</p>

<p><strong>Ghi chú:</strong> ${note}</p>

<a href="menu.jsp">Trở lại</a>

</body>
</html>
