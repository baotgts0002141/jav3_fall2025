<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<a href ="account/login">bai1</a>||
<a href ="calculate">bai2</a>||
<a href ="dangky">bai3</a>||
<a href ="upload">bai4</a>
</body>
</html>