<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Đăng Ký</title>
<style>
    body { font-family: Arial, sans-serif; width: 400px; margin: 20px auto; }
    h1 { text-align: center; }
    label { display: inline-block; width: 120px; }
    input[type=text], input[type=password], select, textarea {
        width: 200px; margin-bottom: 8px;
    }
    textarea { height: 60px; resize: none; }
    .checkbox-group { margin-left: 120px; }
    hr { margin-top: 15px; }
</style>
</head>
<body>
<h1>Đăng Ký</h1>

<form action="dangky" method="post">
    <label>Tên đăng nhập:</label>
    <input type="text" name="fullname" /> <br/>

    <label>Mật khẩu:</label>
    <input type="password" name="password" /> <br/>

    <label>Giới tính:</label>
    <input type="radio" name="gender" value="True" checked/> Nam
    <input type="radio" name="gender" value="False"/> Nữ <br/>

    <label>Đã có gia đình:</label>
    <input type="checkbox" name="married" value="Đã có"/> <br/>

    <label>Quốc tịch:</label>
    <select name="country">
        <option>United States</option>
        <option>Viet Nam</option>
        <option>Japan</option>
        <option>Korea</option>
    </select><br/>

    <label>Sở thích:</label>
    <div class="checkbox-group">
        <input type="checkbox" name="hobbies" value="Đọc sách"/> Đọc sách
        <input type="checkbox" name="hobbies" value="Du lịch"/> Du lịch
        <input type="checkbox" name="hobbies" value="Âm nhạc"/> Âm nhạc
        <input type="checkbox" name="hobbies" value="Khác"/> Khác
    </div><br/>

    <label>Ghi chú:</label>
    <textarea name="note"></textarea> <br/>

    <hr/>
    <input type="submit" value="Đăng ký" />
</form>
</body>
</html>
