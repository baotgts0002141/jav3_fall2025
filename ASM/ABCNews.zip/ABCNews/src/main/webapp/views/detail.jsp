<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<jsp:include page="common/header.jsp"></jsp:include>

<div class="container mt-5">
    <div class="row">
        
        <div class="col-lg-8" data-aos="fade-up">
            
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb bg-white p-3 rounded-pill shadow-sm small border">
                    <li class="breadcrumb-item"><a href="home" class="text-pink text-decoration-none fw-bold">Trang chủ</a></li>
                    <li class="breadcrumb-item active text-pink fw-bold">${news.categoryId}</li>
                    <li class="breadcrumb-item active text-muted text-truncate" style="max-width: 300px;">${news.title}</li>
                </ol>
            </nav>

            <h1 class="fw-bolder mb-3 display-6" style="color: #333; line-height: 1.4;">
                ${news.title}
            </h1>
            
            <div class="d-flex align-items-center mb-4 text-muted border-bottom pb-3">
                <div class="bg-pink text-white rounded-circle d-flex align-items-center justify-content-center me-3 shadow-sm" style="width: 45px; height: 45px;">
                    <i class="bi bi-person-fill fs-5"></i>
                </div>
                <div>
                    <span class="fw-bold text-dark d-block">Tác giả: ${news.authorId}</span>
                    <small class="text-muted">
                        <i class="bi bi-calendar3"></i> ${news.postedDate} &bull; 
                        <i class="bi bi-eye-fill"></i> ${news.viewCount} lượt xem
                    </small>
                </div>
            </div>

            <div class="mb-4 rounded-4 overflow-hidden shadow-lg">
                <c:choose>
                    <c:when test="${news.image != null && news.image.startsWith('http')}">
                        <img src="${news.image}" class="img-fluid w-100" style="object-fit: cover; max-height: 500px;">
                    </c:when>
                    <c:otherwise>
                        <img src="${pageContext.request.contextPath}/${news.image}" class="img-fluid w-100" style="object-fit: cover; max-height: 500px;">
                    </c:otherwise>
                </c:choose>
            </div>

            <div class="content-body fs-5 lh-lg text-justify mb-5" style="color: #444;">
                ${news.content}
            </div>
            
            <hr class="text-pink opacity-100 my-5" style="border-top: 3px solid;">

            <h4 class="text-pink fw-bold mb-4 border-start border-5 border-pink ps-3">
                <i class="bi bi-collection-play-fill"></i> Tin Cùng Chuyên Mục
            </h4>
            
            <div class="row">
                <c:forEach items="${relatedNews}" var="r">
                    <div class="col-md-4 mb-4">
                        <div class="card h-100 border-0 shadow-sm card-news">
                             <div class="card-img-wrapper" style="height: 150px;">
                                <c:choose>
                                    <c:when test="${r.image != null && r.image.startsWith('http')}">
                                        <img src="${r.image}" class="card-img-top">
                                    </c:when>
                                    <c:otherwise>
                                        <img src="${pageContext.request.contextPath}/${r.image}" class="card-img-top">
                                    </c:otherwise>
                                </c:choose>
                            </div>
                            <div class="card-body p-3">
                                <h6 class="card-title mb-0">
                                    <a href="detail?id=${r.id}" class="text-decoration-none text-dark stretched-link hover-pink fw-bold">
                                        ${r.title}
                                    </a>
                                </h6>
                                <small class="text-muted mt-2 d-block">
                                    <i class="bi bi-calendar"></i> ${r.postedDate}
                                </small>
                            </div>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </div>
        
        <div class="col-lg-4 ps-lg-4">
            
            <div class="card mb-4 border-0 shadow-sm bg-white" data-aos="fade-left" data-aos-delay="100">
                <div class="card-body p-4 text-center">
                    <div class="bg-pink text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                        <i class="bi bi-envelope-heart-fill fs-3"></i>
                    </div>
                    <h5 class="card-title fw-bold text-pink">Đăng ký nhận tin</h5>
                    <p class="small text-muted mb-3">Nhập email để không bỏ lỡ tin tức mới nhất.</p>
                    
                    <c:if test="${not empty sessionScope.message}">
                        <div class="alert alert-success py-2 small shadow-sm animate__animated animate__fadeIn">
                            <i class="bi bi-check-circle-fill"></i> ${sessionScope.message}
                        </div>
                        <% session.removeAttribute("message"); %>
                    </c:if>

                    <c:if test="${not empty sessionScope.error}">
                        <div class="alert alert-danger py-2 small shadow-sm animate__animated animate__shakeX">
                            <i class="bi bi-exclamation-triangle-fill"></i> ${sessionScope.error}
                        </div>
                        <% session.removeAttribute("error"); %>
                    </c:if>
                    <form action="${pageContext.request.contextPath}/newsletter" method="post">
                        <div class="mb-3">
                            <input type="email" name="email" class="form-control rounded-pill px-3 bg-light" placeholder="Nhập email..." required>
                        </div>
                        <button type="submit" class="btn btn-pink w-100 rounded-pill fw-bold shadow-sm">Đăng ký ngay</button>
                    </form>
                </div>
            </div>

            <div class="card border-0 shadow-sm" data-aos="fade-left" data-aos-delay="200">
                <div class="card-header bg-white border-0 pt-3 pb-0">
                    <h5 class="text-pink fw-bold m-0"><i class="bi bi-star-fill"></i> Có thể bạn quan tâm</h5>
                </div>
                
                <div class="list-group list-group-flush mt-2">
                    <c:if test="${empty topNews}">
                        <div class="p-3 text-muted fst-italic">Đang cập nhật danh sách...</div>
                    </c:if>

                    <c:forEach items="${topNews}" var="t" varStatus="loop">
                        <a href="detail?id=${t.id}" class="list-group-item list-group-item-action py-3 border-0">
                            <div class="d-flex align-items-center">
                                <span class="fs-2 fw-bold text-pink opacity-25 me-3">
                                    <c:if test="${loop.index < 9}">0</c:if>${loop.index + 1}
                                </span>
                                
                                <div>
                                    <h6 class="mb-1 fw-bold text-dark text-truncate" style="max-width: 220px;">
                                        ${t.title}
                                    </h6>
                                    <small class="text-muted"><i class="bi bi-eye"></i> ${t.viewCount} views</small>
                                </div>
                            </div>
                        </a>
                    </c:forEach>
                </div>
            </div>
            
        </div>
    </div>
</div>

<div class="mb-5"></div>
<jsp:include page="common/footer.jsp"></jsp:include>