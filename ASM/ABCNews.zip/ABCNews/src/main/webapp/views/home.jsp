<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<jsp:include page="common/header.jsp"></jsp:include>

    <header class="hero-section text-center" data-aos="fade-down">
        <div class="container">
            <h1 class="display-4 fw-bold">Chào mừng đến với ABC News</h1>
            <p class="lead opacity-75">Cập nhật tin tức nóng hổi, chính xác và nhanh chóng</p>
            <a href="#news-section" class="btn btn-light text-pink rounded-pill mt-3 px-4 fw-bold shadow">Khám phá ngay</a>
        </div>
    </header>

    <div class="container" id="news-section">
        <div class="row">
            <div class="col-md-8">
                <h3 class="border-bottom border-danger pb-2 mb-4 text-pink fw-bold" data-aos="fade-right">
                    <i class="bi bi-fire"></i> Tin Mới Nhất
                </h3>
                
                <div class="row">
                    <c:forEach items="${listNews}" var="n" varStatus="loop">
                        <div class="col-md-6 mb-4" data-aos="fade-up" data-aos-delay="${loop.index * 100}">
                            <div class="card h-100 card-news">
                                <div class="card-img-wrapper">
                                    <c:choose>
                                        <c:when test="${n.image != null && n.image.startsWith('http')}">
                                            <img src="${n.image}" class="card-img-top" alt="${n.title}">
                                        </c:when>
                                        <c:otherwise>
                                            <img src="${pageContext.request.contextPath}/${n.image}" class="card-img-top" alt="${n.title}">
                                        </c:otherwise>
                                    </c:choose>
                                </div>

                                <div class="card-body">
                                    <h5 class="card-title text-truncate">
                                        <a href="detail?id=${n.id}" class="text-decoration-none text-dark stretched-link" style="color: black; font-weight: bold;">${n.title}</a>
                                    </h5>
                                    <p class="card-text text-muted small">
                                        <i class="bi bi-clock"></i> ${n.postedDate} | 
                                        
                                        <span class="badge bg-white text-dark border border-pink" style="color: black !important;">
                                            ${n.categoryId}
                                        </span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </c:forEach>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card mb-4 border-0 shadow-sm" data-aos="fade-left" data-aos-delay="200">
                    <div class="card-body bg-white rounded-3">
                        <h5 class="card-title text-pink fw-bold">
                            <i class="bi bi-envelope-heart"></i> Đăng ký nhận tin
                        </h5>
                        <p class="small text-muted">Nhập email để không bỏ lỡ tin tức mới.</p>
                        
                        <c:if test="${not empty sessionScope.message}">
                            <div class="alert alert-success py-2 small shadow-sm animate__animated animate__fadeIn">
                                <i class="bi bi-check-circle-fill"></i> ${sessionScope.message}
                            </div>
                            <% session.removeAttribute("message"); %>
                        </c:if>

                        <c:if test="${not empty sessionScope.error}">
                            <div class="alert alert-danger py-2 small shadow-sm animate__animated animate__shakeX">
                                <i class="bi bi-exclamation-triangle-fill"></i> ${sessionScope.error}
                            </div>
                            <% session.removeAttribute("error"); %>
                        </c:if>

                        <form action="${pageContext.request.contextPath}/newsletter" method="post">
                            <div class="mb-3">
                                <input type="email" name="email" class="form-control rounded-pill px-3" placeholder="email@example.com" required>
                            </div>
                            <button type="submit" class="btn btn-pink w-100 fw-bold">Đăng ký ngay</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<jsp:include page="common/footer.jsp"></jsp:include>