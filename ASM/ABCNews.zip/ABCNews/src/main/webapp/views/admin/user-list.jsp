<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<jsp:include page="../common/header.jsp"></jsp:include>

<div class="container mt-4">
    <div class="row">
        
        <div class="col-md-3 mb-4" data-aos="fade-right">
            <jsp:include page="../common/sidebar.jsp">
                <jsp:param name="active" value="users"/>
            </jsp:include>
        </div>

        <div class="col-md-9" data-aos="fade-up">
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
                    <h3 class="text-pink fw-bold m-0">
                        <i class="bi bi-people-fill"></i> Quản Lý Người Dùng
                    </h3>
                    <a href="${pageContext.request.contextPath}/admin/user-form" class="btn btn-pink shadow-sm rounded-pill px-3">
                        <i class="bi bi-person-plus-fill"></i> Thêm mới
                    </a>
                </div>

                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light text-secondary">
                                <tr>
                                    <th class="ps-4">Username</th>
                                    <th>Họ và tên</th>
                                    <th>Email</th>
                                    <th>Vai trò</th>
                                    <th class="text-center">Hành động</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach items="${users}" var="u">
                                    <tr>
                                        <td class="ps-4 fw-bold text-muted">#${u.id}</td>
                                        <td><span class="fw-bold text-dark">${u.fullname}</span></td>
                                        <td><span class="text-muted small">${u.email}</span></td>
                                        <td>
                                            <c:if test="${u.role}">
                                                <span class="badge rounded-pill bg-danger bg-opacity-10 text-danger border border-danger">Admin</span>
                                            </c:if>
                                            <c:if test="${!u.role}">
                                                <span class="badge rounded-pill bg-info bg-opacity-10 text-info border border-info">Phóng viên</span>
                                            </c:if>
                                        </td>
                                        <td class="text-center">
                                            <a href="${pageContext.request.contextPath}/admin/user-form?id=${u.id}" class="btn btn-sm btn-light text-primary rounded-circle shadow-sm me-1" title="Sửa">
                                                <i class="bi bi-pencil-fill"></i>
                                            </a>
                                            <a href="#" onclick="confirmDelete('${u.id}')" class="btn btn-sm btn-light text-danger rounded-circle shadow-sm" title="Xóa">
                                                <i class="bi bi-trash-fill"></i>
                                            </a>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                    
                    <c:if test="${empty users}">
                        <div class="text-center py-5 text-muted">
                            <i class="bi bi-people fs-1 opacity-50"></i>
                            <p class="mt-2">Chưa có người dùng nào.</p>
                        </div>
                    </c:if>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmDelete(id) {
        if (confirm("CẢNH BÁO: Xóa người dùng này sẽ xóa tất cả bài viết của họ!\nBạn có chắc chắn muốn tiếp tục?")) {
            window.location.href = "${pageContext.request.contextPath}/delete-user?id=" + id;
        }
    }
</script>

<div class="mb-5"></div>
<jsp:include page="../common/footer.jsp"></jsp:include>