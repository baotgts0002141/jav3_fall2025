<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<jsp:include page="../common/header.jsp"></jsp:include>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-3 mb-4" data-aos="fade-right">
            <jsp:include page="../common/sidebar.jsp">
                <jsp:param name="active" value="categories"/>
            </jsp:include>
        </div>

        <div class="col-md-9" data-aos="fade-up">
            <div class="card border-0 shadow-lg rounded-4">
                <div class="card-header bg-white border-0 py-3">
                    <h4 class="mb-0 fw-bold text-pink">
                        <i class="bi bi-tag-fill"></i> 
                        <c:if test="${isEdit}">Cập nhật Loại tin</c:if>
                        <c:if test="${!isEdit}">Thêm Loại tin mới</c:if>
                    </h4>
                </div>
                <div class="card-body p-4">
                    <form action="${pageContext.request.contextPath}/category-form" method="post">
                        
                        <div class="mb-4">
                            <label class="form-label fw-bold">Mã loại tin (ID)</label>
                            <input type="text" name="id" class="form-control form-control-lg bg-light" value="${category.id}" required 
                                <c:if test="${isEdit}">readonly</c:if> placeholder="VD: DL (Du lịch)">
                            <div class="form-text">Mã loại tin viết tắt (VD: VH, TT, PL) và không thể sửa sau khi tạo.</div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold">Tên loại tin</label>
                            <input type="text" name="name" class="form-control form-control-lg" value="${category.name}" required placeholder="VD: Du lịch bốn phương">
                        </div>

                        <div class="d-flex justify-content-end gap-2 border-top pt-4">
                            <a href="${pageContext.request.contextPath}/admin/categories" class="btn btn-light px-4 rounded-pill">Quay lại</a>
                            <button type="submit" class="btn btn-pink px-5 fw-bold shadow-sm rounded-pill">
                                <i class="bi bi-save"></i> Lưu dữ liệu
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="mb-5"></div>
<jsp:include page="../common/footer.jsp"></jsp:include>