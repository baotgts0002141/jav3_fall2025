<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<jsp:include page="../common/header.jsp"></jsp:include>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-3 mb-4" data-aos="fade-right">
            <jsp:include page="../common/sidebar.jsp">
                <jsp:param name="active" value="users"/>
            </jsp:include>
        </div>

        <div class="col-md-9" data-aos="fade-up">
            <div class="card border-0 shadow-lg rounded-4">
                <div class="card-header bg-white border-0 py-3">
                    <h4 class="mb-0 fw-bold text-pink">
                        <i class="bi bi-person-lines-fill"></i> Thông tin Người dùng
                    </h4>
                </div>
                <div class="card-body p-4">
                    <form action="${pageContext.request.contextPath}/admin/user-form" method="post">
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Username</label>
                                <input type="text" name="id" class="form-control bg-light" value="${user.id}" required <c:if test="${isEdit}">readonly</c:if>>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Mật khẩu</label>
                                <input type="password" name="password" class="form-control" value="${user.password}" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Họ và tên</label>
                            <input type="text" name="fullname" class="form-control" value="${user.fullname}" required>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Email</label>
                                <input type="email" name="email" class="form-control" value="${user.email}">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Số điện thoại</label>
                                <input type="text" name="mobile" class="form-control" value="${user.mobile}">
                            </div>
                        </div>

                        <div class="mb-3 p-3 bg-light rounded-3">
                            <label class="form-label fw-bold d-block">Vai trò hệ thống</label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="role" value="true" id="adminRole" ${user.role ? 'checked' : ''}>
                                <label class="form-check-label fw-bold text-danger" for="adminRole">Quản Trị Viên</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="role" value="false" id="reporterRole" ${!user.role ? 'checked' : ''}>
                                <label class="form-check-label fw-bold text-info" for="reporterRole">Phóng Viên</label>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end gap-2 border-top pt-3">
                            <a href="${pageContext.request.contextPath}/admin/users" class="btn btn-light px-4 rounded-pill">Quay lại</a>
                            <button type="submit" class="btn btn-pink px-5 fw-bold shadow-sm rounded-pill">Lưu thông tin</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<jsp:include page="../common/footer.jsp"></jsp:include>