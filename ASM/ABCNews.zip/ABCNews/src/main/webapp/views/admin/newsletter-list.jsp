<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<jsp:include page="../common/header.jsp"></jsp:include>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-3 mb-4" data-aos="fade-right">
            <jsp:include page="../common/sidebar.jsp">
                <jsp:param name="active" value="newsletters"/>
            </jsp:include>
        </div>

        <div class="col-md-9" data-aos="fade-up">
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                <div class="card-header bg-white border-0 py-3">
                    <h3 class="text-pink fw-bold m-0">
                        <i class="bi bi-envelope-paper-fill"></i> Quản Lý Newsletter
                    </h3>
                </div>

                <div class="card-body p-0">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light text-secondary">
                            <tr>
                                <th class="ps-4">Email đăng ký</th>
                                <th class="text-center">Hành động</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach items="${emails}" var="e">
                                <tr>
                                    <td class="ps-4 fw-bold text-dark">${e}</td>
                                    <td class="text-center">
                                        <a href="#" onclick="confirmDelete('${e}')" class="btn btn-sm btn-light text-danger rounded-circle shadow-sm" title="Xóa">
                                            <i class="bi bi-trash-fill"></i>
                                        </a>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                    
                    <c:if test="${empty emails}">
                        <div class="text-center py-5 text-muted">
                            <i class="bi bi-inbox fs-1 opacity-50"></i>
                            <p class="mt-2">Chưa có email nào đăng ký.</p>
                        </div>
                    </c:if>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmDelete(email) {
        if (confirm("Bạn có chắc muốn xóa email " + email + " khỏi danh sách nhận tin?")) {
            window.location.href = "${pageContext.request.contextPath}/delete-newsletter?email=" + email;
        }
    }
</script>

<div class="mb-5"></div>
<jsp:include page="../common/footer.jsp"></jsp:include>