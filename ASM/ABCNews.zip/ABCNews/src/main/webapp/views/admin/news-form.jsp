<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<jsp:include page="../common/header.jsp"></jsp:include>

<div class="container mt-4">
    <div class="row">
        
        <div class="col-md-3 mb-4" data-aos="fade-right">
            <jsp:include page="../common/sidebar.jsp">
                <jsp:param name="active" value="news"/>
            </jsp:include>
        </div>

        <div class="col-md-9" data-aos="fade-up">
            <div class="card border-0 shadow-lg rounded-4">
                <div class="card-header bg-white border-0 py-3">
                    <h4 class="mb-0 fw-bold text-pink">
                        <i class="bi bi-pencil-square"></i> 
                        <c:if test="${isEdit}">Cập nhật bài viết</c:if>
                        <c:if test="${!isEdit}">Đăng bài viết mới</c:if>
                    </h4>
                </div>
                <div class="card-body p-4">
                    <form action="${pageContext.request.contextPath}/admin/news-form" method="post" enctype="multipart/form-data">
                        
                        <input type="hidden" name="isEditMode" value="${isEdit}">

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Mã bản tin (ID)</label>
                                
                                <input type="text" name="id" 
                                       class="form-control form-control-lg bg-light ${not empty errorId ? 'is-invalid' : ''}" 
                                       value="${news.id}" required 
                                       placeholder="VD: N005"
                                       <c:if test="${isEdit}">readonly</c:if> >
                                
                                <c:if test="${not empty errorId}">
                                    <div class="invalid-feedback fw-bold">
                                        <i class="bi bi-exclamation-triangle-fill"></i> ${errorId}
                                    </div>
                                </c:if>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Loại tin</label>
                                <select name="categoryId" class="form-select form-select-lg">
                                    <c:forEach items="${categories}" var="c">
                                        <option value="${c.id}" ${c.id == news.categoryId ? 'selected' : ''}>
                                            ${c.name}
                                        </option>
                                    </c:forEach>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Tiêu đề</label>
                            <input type="text" name="title" class="form-control form-control-lg" value="${news.title}" required placeholder="Nhập tiêu đề...">
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Hình ảnh</label>
                            <input type="file" name="imageFile" class="form-control" accept="image/*">
                            <input type="hidden" name="currentImage" value="${news.image}">
                            
                            <c:if test="${not empty news.image}">
                                <div class="mt-3 p-2 border rounded bg-light d-inline-block">
                                    <small class="text-muted d-block mb-1">Ảnh hiện tại:</small>
                                    <c:choose>
                                        <c:when test="${news.image.startsWith('http')}">
                                            <img src="${news.image}" height="80" class="rounded">
                                        </c:when>
                                        <c:otherwise>
                                            <img src="${pageContext.request.contextPath}/${news.image}" height="80" class="rounded">
                                        </c:otherwise>
                                    </c:choose>
                                </div>
                            </c:if>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Nội dung</label>
                            <textarea name="content" class="form-control" rows="8" required placeholder="Nội dung chi tiết...">${news.content}</textarea>
                        </div>

                        <div class="form-check form-switch mb-4">
                            <input class="form-check-input" type="checkbox" id="homeCheck" name="home" value="true" ${news.home ? 'checked' : ''}>
                            <label class="form-check-label" for="homeCheck">Hiển thị lên Trang chủ</label>
                        </div>

                        <div class="d-flex justify-content-end gap-2 border-top pt-3">
                            <a href="${pageContext.request.contextPath}/admin/news" class="btn btn-light px-4 rounded-pill">Hủy bỏ</a>
                            <button type="submit" class="btn btn-pink px-5 fw-bold shadow-sm rounded-pill">
                                <i class="bi bi-save"></i> Lưu bài viết
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="mb-5"></div>
<jsp:include page="../common/footer.jsp"></jsp:include>