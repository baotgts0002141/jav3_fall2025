<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<jsp:include page="../common/header.jsp"></jsp:include>

<div class="container mt-4">
    <div class="row">
        
        <div class="col-md-3 mb-4" data-aos="fade-right">
            <jsp:include page="../common/sidebar.jsp">
                <jsp:param name="active" value="news"/>
            </jsp:include>
        </div>

        <div class="col-md-9" data-aos="fade-up">
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                
                <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
                    <h3 class="text-pink fw-bold m-0">
                        <i class="bi bi-newspaper"></i> Quản Lý Tin Tức
                    </h3>
                    
                    <a href="${pageContext.request.contextPath}/admin/news-form" class="btn btn-pink shadow-sm rounded-pill px-3">
                        <i class="bi bi-plus-lg"></i> Đăng tin mới
                    </a>
                </div>
                
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light text-secondary">
                                <tr>
                                    <th class="ps-4">ID</th>
                                    <th>Hình ảnh</th>
                                    <th style="width: 30%;">Tiêu đề</th>
                                    <th>Ngày đăng</th>
                                    <th>Tác giả</th>
                                    <th>Views</th>
                                    <th class="text-center">Hành động</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach items="${listNews}" var="n">
                                    <tr>
                                        <td class="ps-4 fw-bold text-muted">#${n.id}</td>
                                        
                                        <td>
                                            <div class="rounded overflow-hidden shadow-sm border" style="width: 60px; height: 40px;">
                                                <c:choose>
                                                    <c:when test="${n.image != null && n.image.startsWith('http')}">
                                                        <img src="${n.image}" style="width: 100%; height: 100%; object-fit: cover;">
                                                    </c:when>
                                                    <c:otherwise>
                                                        <img src="${pageContext.request.contextPath}/${n.image}" style="width: 100%; height: 100%; object-fit: cover;">
                                                    </c:otherwise>
                                                </c:choose>
                                            </div>
                                        </td>
                                        
                                        <td><span class="d-inline-block text-truncate fw-bold text-dark" style="max-width: 250px;">${n.title}</span></td>
                                        <td><small class="text-muted">${n.postedDate}</small></td>
                                        <td><span class="badge rounded-pill bg-light text-dark border">${n.authorId}</span></td>
                                        <td><span class="badge bg-secondary opacity-75">${n.viewCount}</span></td>
                                        
                                        <td class="text-center">
                                            <a href="${pageContext.request.contextPath}/admin/news-form?id=${n.id}" class="btn btn-sm btn-light text-primary rounded-circle shadow-sm me-1"><i class="bi bi-pencil-fill"></i></a>
                                            <a href="#" onclick="confirmDelete('${n.id}')" class="btn btn-sm btn-light text-danger rounded-circle shadow-sm"><i class="bi bi-trash-fill"></i></a>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                    
                    <c:if test="${empty listNews}">
                        <div class="text-center py-5 text-muted">
                            <i class="bi bi-inbox fs-1 opacity-25"></i>
                            <p class="mt-2">Bạn chưa đăng bài viết nào.</p>
                        </div>
                    </c:if>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmDelete(id) {
        if (confirm("Bạn có chắc chắn muốn xóa bài viết " + id + "?")) {
            window.location.href = "${pageContext.request.contextPath}/delete-news?id=" + id;
        }
    }
</script>

<div class="mb-5"></div>
<jsp:include page="../common/footer.jsp"></jsp:include>