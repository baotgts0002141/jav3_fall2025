<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<jsp:include page="../common/header.jsp"></jsp:include>

<div class="container mt-4">
    <div class="row">
        
        <div class="col-md-3 mb-4" data-aos="fade-right">
            <jsp:include page="../common/sidebar.jsp">
                <jsp:param name="active" value="categories"/>
            </jsp:include>
        </div>

        <div class="col-md-9" data-aos="fade-up">
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
                    <h3 class="text-pink fw-bold m-0">
                        <i class="bi bi-tags-fill"></i> Quản Lý Loại Tin
                    </h3>
                    <a href="${pageContext.request.contextPath}/category-form" class="btn btn-pink shadow-sm rounded-pill px-3">
                        <i class="bi bi-plus-lg"></i> Thêm loại tin
                    </a>
                </div>

                <div class="card-body p-0">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light text-secondary">
                            <tr>
                                <th class="ps-4">Mã loại (ID)</th>
                                <th>Tên loại tin</th>
                                <th class="text-center">Hành động</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach items="${categories}" var="c">
                                <tr>
                                    <td class="ps-4">
                                        <span class="badge bg-secondary rounded-1">${c.id}</span>
                                    </td>
                                    <td><span class="fw-bold text-dark fs-6">${c.name}</span></td>
                                    <td class="text-center">
                                        <a href="${pageContext.request.contextPath}/category-form?id=${c.id}" class="btn btn-sm btn-light text-primary rounded-circle shadow-sm me-1" title="Sửa">
                                            <i class="bi bi-pencil-fill"></i>
                                        </a>
                                        <a href="#" onclick="confirmDelete('${c.id}')" class="btn btn-sm btn-light text-danger rounded-circle shadow-sm" title="Xóa">
                                            <i class="bi bi-trash-fill"></i>
                                        </a>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>

                    <c:if test="${empty categories}">
                        <div class="text-center py-5 text-muted">
                            <i class="bi bi-tags fs-1 opacity-50"></i>
                            <p class="mt-2">Chưa có danh mục nào.</p>
                        </div>
                    </c:if>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmDelete(id) {
        if (confirm("LƯU Ý: Xóa loại tin này có thể ảnh hưởng đến các bài viết thuộc về nó.\nBạn có chắc chắn muốn xóa?")) {
            window.location.href = "${pageContext.request.contextPath}/delete-category?id=" + id;
        }
    }
</script>

<div class="mb-5"></div>
<jsp:include page="../common/footer.jsp"></jsp:include>