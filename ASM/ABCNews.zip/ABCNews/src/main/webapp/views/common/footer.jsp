<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

    <footer class="text-center py-5 mt-5" 
            style="background: linear-gradient(135deg, #FF69B4 0%, #FF1493 100%); 
                   color: white; 
                   border-radius: 50px 50px 0 0; 
                   box-shadow: 0 -10px 20px rgba(255, 105, 180, 0.2);">
        
        <div class="container">
            <h2 class="fw-bold mb-3" style="letter-spacing: 1px; text-shadow: 1px 1px 2px rgba(0,0,0,0.1);" data-aos="zoom-in">
                ABC News
            </h2>
            
            <p class="mb-1" style="opacity: 0.9;">
                Cập nhật tin tức nóng hổi, chính xác và nhanh chóng.
            </p>
            
            <p class="small mb-4" style="opacity: 0.8;">
                Thiết kế bởi <strong>An Đông</strong>
            </p>
        </div>
    </footer>

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 800, 
            once: true,    
            offset: 50     
        });
    </script>
    
    <style>
        .hover-scale { transition: all 0.3s; display: inline-block; }
        .hover-scale:hover { transform: scale(1.2); opacity: 1 !important; }
    </style>
</body>
</html>