<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="vi">
<head>
    <title>ABC News</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <link href="${pageContext.request.contextPath}/css/style.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm" id="mainNavbar">
    <div class="container">
        <a class="navbar-brand text-pink fw-bold fs-3" href="${pageContext.request.contextPath}/home">ABCNews</a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/home">Trang chủ</a></li>
                
                <c:forEach items="${globalCategories}" var="c">
                    <li class="nav-item">
                        <a class="nav-link" href="${pageContext.request.contextPath}/category?cid=${c.id}">${c.name}</a>
                    </li>
                </c:forEach>
               <!-- Tìm kiếm --> 
                <li class="nav-item ms-3">
				    <form action="search" method="get" class="d-flex"> 
				        <div class="input-group input-group-sm">
				            <input type="search" 
				                   name="txt" 
				                   value="${param.txt}" 
				                   class="form-control rounded-start-pill border-end-0" 
				                   placeholder="Tìm kiếm...">
				            
				            <button class="btn btn-outline-secondary rounded-end-pill border-start-0" type="submit">
				                <i class="bi bi-search"></i>
				            </button>
				        </div>
				    </form>
				</li>
                
                <c:if test="${empty sessionScope.account}">
                    <li class="nav-item ms-3">
                        <a href="${pageContext.request.contextPath}/login" class="btn btn-outline-danger rounded-pill px-4 btn-sm">Đăng nhập</a>
                    </li>
                </c:if>

                <c:if test="${not empty sessionScope.account}">
                    <li class="nav-item ms-3 dropdown">
                        <a class="nav-link dropdown-toggle text-pink fw-bold" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Xin chào, ${sessionScope.account.fullname}
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end border-0 shadow">
                           <c:if test="${sessionScope.account.role == true}">
							    <li><a class="dropdown-item" href="${pageContext.request.contextPath}/admin/news">Quản lý Tin tức</a></li>
							    <li><a class="dropdown-item" href="${pageContext.request.contextPath}/admin/categories">Quản lý Loại tin</a></li>
							    <li><a class="dropdown-item" href="${pageContext.request.contextPath}/admin/users">Quản lý Người dùng</a></li>
                                <li><a class="dropdown-item" href="${pageContext.request.contextPath}/admin/newsletters">Quản lý Newsletter</a></li>
						   </c:if>
                           <c:if test="${sessionScope.account.role == false}">
                                <li><a class="dropdown-item" href="${pageContext.request.contextPath}/reporter/news">Tin tức của tôi</a></li>
                           </c:if>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="${pageContext.request.contextPath}/logout">Đăng xuất</a></li>
                        </ul>
                    </li>
                </c:if>
            </ul>
        </div>
    </div>
</nav>