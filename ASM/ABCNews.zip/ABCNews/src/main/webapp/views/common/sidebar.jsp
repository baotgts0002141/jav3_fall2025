<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-pink text-white fw-bold">
        <i class="bi bi-speedometer2"></i> MENU QUẢN TRỊ
    </div>
    <div class="list-group list-group-flush">
        
        <a href="${pageContext.request.contextPath}/admin/news" 
           class="list-group-item list-group-item-action ${param.active == 'news' ? 'active-pink' : ''}">
            <i class="bi bi-newspaper me-2"></i> Quản lý Tin tức
        </a>
    
        <c:if test="${sessionScope.account.role == true}">
            
            <a href="${pageContext.request.contextPath}/admin/categories" 
               class="list-group-item list-group-item-action ${param.active == 'categories' ? 'active-pink' : ''}">
                <i class="bi bi-tags me-2"></i> Quản lý Loại tin
            </a>

            <a href="${pageContext.request.contextPath}/admin/users" 
               class="list-group-item list-group-item-action ${param.active == 'users' ? 'active-pink' : ''}">
                <i class="bi bi-people me-2"></i> Quản lý Người dùng
            </a>
            
            <a href="${pageContext.request.contextPath}/admin/newsletters" 
               class="list-group-item list-group-item-action ${param.active == 'newsletters' ? 'active-pink' : ''}">
                <i class="bi bi-envelope-paper me-2"></i> Quản lý Newsletter
            </a>
            
        </c:if>

        <div class="list-group-item"></div>

        <a href="${pageContext.request.contextPath}/logout" class="list-group-item list-group-item-action text-muted">
            <i class="bi bi-box-arrow-right me-2"></i> Đăng xuất
        </a>
    </div>
</div>