<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>ABC News | Đăng nhập Quản trị</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');

        /* --- 1. HÌNH NỀN CHUYỂN ĐỘNG --- */
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(-45deg, #ff9a9e, #fad0c4, #ffecd2, #fcb69f);
            background-size: 400% 400%;
            animation: gradientBG 15s ease infinite;
            height: 100vh;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* --- 2. PARTICLES (KHỐI BAY) --- */
        .circles {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
            margin: 0;
            padding: 0;
        }

        .circles li {
            position: absolute;
            display: block;
            list-style: none;
            width: 20px;
            height: 20px;
            background: rgba(255, 255, 255, 0.6); /* Tăng độ rõ của khối */
            animation: animate 25s linear infinite;
            bottom: -150px;
            border-radius: 20%;
        }

        .circles li:nth-child(1) { left: 25%; width: 80px; height: 80px; animation-delay: 0s; }
        .circles li:nth-child(2) { left: 10%; width: 20px; height: 20px; animation-delay: 2s; animation-duration: 12s; }
        .circles li:nth-child(3) { left: 70%; width: 20px; height: 20px; animation-delay: 4s; }
        .circles li:nth-child(4) { left: 40%; width: 60px; height: 60px; animation-delay: 0s; animation-duration: 18s; }
        .circles li:nth-child(5) { left: 65%; width: 20px; height: 20px; animation-delay: 0s; }
        .circles li:nth-child(6) { left: 75%; width: 110px; height: 110px; animation-delay: 3s; }
        .circles li:nth-child(7) { left: 35%; width: 150px; height: 150px; animation-delay: 7s; }
        .circles li:nth-child(8) { left: 50%; width: 25px; height: 25px; animation-delay: 15s; animation-duration: 45s; }
        .circles li:nth-child(9) { left: 20%; width: 15px; height: 15px; animation-delay: 2s; animation-duration: 35s; }
        .circles li:nth-child(10){ left: 85%; width: 150px; height: 150px; animation-delay: 0s; animation-duration: 11s; }

        @keyframes animate {
            0% { transform: translateY(0) rotate(0deg); opacity: 1; border-radius: 0; }
            100% { transform: translateY(-1000px) rotate(720deg); opacity: 0; border-radius: 50%; }
        }

        /* --- 3. FORM KÍNH (ĐÃ CHỈNH SỬA ĐỂ RÕ CHỮ) --- */
        .glass-container {
            position: relative;
            z-index: 10;
            /* Tăng độ đục (Opacity) lên 0.85 để nền trắng rõ hơn, chữ sẽ nổi bật hơn */
            background: rgba(255, 255, 255, 0.85); 
            box-shadow: 0 15px 35px rgba(0,0,0,0.2); /* Bóng đổ đậm hơn để tách biệt với nền */
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.9);
            padding: 50px;
            width: 450px;
            max-width: 90%;
            text-align: center;
            animation: fadeInDown 1s ease;
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .logo-circle {
            width: 90px;
            height: 90px;
            background: linear-gradient(135deg, #ff69b4, #ff1493);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 45px;
            color: white;
            margin: 0 auto 20px;
            box-shadow: 0 5px 15px rgba(255, 105, 180, 0.4);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(255, 105, 180, 0.7); }
            70% { transform: scale(1.05); box-shadow: 0 0 0 15px rgba(255, 105, 180, 0); }
            100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(255, 105, 180, 0); }
        }

        /* CHỈNH LẠI MÀU CHỮ SANG TÔNG TỐI */
        h2 { 
            color: #d63384; /* Màu hồng đậm */
            font-weight: 700; 
            margin-bottom: 5px;
        }
        
        p.subtitle { 
            color: #6c757d; /* Màu xám ghi */
            margin-bottom: 30px; 
            font-weight: 500;
        }

        /* Input nền xám nhạt, chữ đen */
        .input-group-text { 
            background: #f8f9fa; 
            border: 1px solid #dee2e6; 
            border-right: none;
            color: #d63384; 
        }
        
        .form-control {
            background: #f8f9fa; 
            border: 1px solid #dee2e6; 
            border-left: none;
            color: #333 !important; /* Bắt buộc chữ màu đen */
            padding: 12px;
            font-weight: 500;
        }

        .form-control::placeholder { 
            color: #adb5bd; /* Placeholder màu xám nhạt vừa phải */
        }
        
        .form-control:focus { 
            background: #fff; 
            box-shadow: none; 
            border-color: #ff69b4;
            color: #000;
        }
        
        /* Hiệu ứng focus cho icon bên cạnh input */
        .form-control:focus + .input-group-text, 
        .input-group:focus-within .input-group-text {
            background: #fff;
            border-color: #ff69b4;
        }

        .btn-glass {
            background: linear-gradient(45deg, #ff69b4, #ff4757);
            border: none; width: 100%; padding: 12px; border-radius: 50px;
            color: white; font-weight: 700; font-size: 1.1rem; margin-top: 20px;
            transition: 0.3s; 
            box-shadow: 0 5px 15px rgba(255, 20, 147, 0.3);
        }
        .btn-glass:hover {
            transform: translateY(-2px); 
            box-shadow: 0 8px 20px rgba(255, 20, 147, 0.5);
            background: linear-gradient(45deg, #ff4757, #ff69b4);
        }

        .bottom-links a { 
            color: #666; /* Link màu xám đậm */
            text-decoration: none; 
            transition: 0.3s; 
            font-weight: 500;
        }
        .bottom-links a:hover { 
            color: #ff69b4; /* Hover ra màu hồng */
            text-decoration: none; 
        }
        
        .form-check-label {
            color: #666; /* Chữ Ghi nhớ màu xám */
            font-size: 0.9rem;
        }
        
        .alert-glass {
            background: rgba(255, 235, 238, 0.9); 
            color: #dc3545; 
            border: 1px solid #ffcdd2;
        }
    </style>
</head>
<body>

    <ul class="circles">
        <li></li><li></li><li></li><li></li><li></li>
        <li></li><li></li><li></li><li></li><li></li>
    </ul>

    <div class="glass-container">
        <div class="logo-circle">
            <i class="bi bi-newspaper"></i>
        </div>

        <h2>Xin Chào!</h2>
        <p class="subtitle">Đăng nhập Quản trị ABC News</p>

        <c:if test="${not empty error}">
            <div class="alert alert-glass rounded-3 py-2 small mb-3 d-flex align-items-center justify-content-center">
                <i class="bi bi-exclamation-triangle-fill me-2"></i> ${error}
            </div>
        </c:if>

        <form action="login" method="post">
            <div class="input-group mb-3">
                <span class="input-group-text rounded-start-4 ps-3"><i class="bi bi-person-fill"></i></span>
                <input type="text" name="username" class="form-control rounded-end-4" placeholder="Tên đăng nhập" required>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text rounded-start-4 ps-3"><i class="bi bi-shield-lock-fill"></i></span>
                <input type="password" name="password" class="form-control rounded-end-4" placeholder="Mật khẩu" required>
            </div>

            <div class="d-flex justify-content-between align-items-center mt-3 mb-2 px-1">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="rememberMe" style="border-color: #ccc;">
                    <label class="form-check-label" for="rememberMe">Ghi nhớ</label>
                </div>
                <a href="#" class="small text-decoration-none opacity-75 hover-opacity-100" style="color: #666;">Quên mật khẩu?</a>
            </div>

            <button type="submit" class="btn btn-glass">
                Đăng nhập ngay
            </button>
        </form>

        <div class="bottom-links mt-4 pt-3 border-top border-secondary border-opacity-10">
            <a href="home"><i class="bi bi-arrow-left"></i> Quay về Trang chủ</a>
        </div>
    </div>

</body>
</html>