package com.abcnews.utils;

import com.abcnews.model.User;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@WebFilter(urlPatterns = {"/admin/*", "/reporter/*"}) 
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        
        String uri = req.getRequestURI();
        
        // 1. Cho phép qua nếu là Login, Logout hoặc resource tĩnh
        if (uri.contains("login") || uri.contains("Login") || uri.contains("logout") || 
            uri.contains(".css") || uri.contains(".js") || uri.contains(".png") || uri.contains(".jpg")) {
            chain.doFilter(request, response);
            return;
        }

        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("account");

        // 2. Logic kiểm tra đăng nhập
        if (user == null) {
            String message = "Vui lòng đăng nhập";
            String encodedMessage = URLEncoder.encode(message, StandardCharsets.UTF_8);
            res.sendRedirect(req.getContextPath() + "/login?error=" + encodedMessage);
        } 
        else {
            // 3. LOGIC PHÂN QUYỀN (SỬA TẠI ĐÂY)
            // Nếu user là Phóng viên (Role = false)
            if (!user.isRole()) {
                // Chặn truy cập vào CẢ 3 MỤC: Users, Categories, Newsletters
                // (Chỉ cho phép vào /admin/news hoặc /admin/news-form)
                if (uri.contains("/admin/users") || 
                    uri.contains("/admin/categories") || 
                    uri.contains("/admin/newsletters")) {
                    
                    res.setCharacterEncoding("UTF-8");
                    res.sendError(403, "Bạn không có quyền truy cập trang này!");
                    return; // Dừng ngay, không cho đi tiếp
                }
            }
            
            // Nếu không vi phạm gì thì cho qua
            chain.doFilter(request, response); 
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void destroy() {}
}