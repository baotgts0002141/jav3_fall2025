package com.abcnews.controller;

import com.abcnews.dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/delete-user")
public class DeleteUserServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        // Không cho phép xóa chính mình (nếu cần) hoặc kiểm tra ràng buộc khóa ngoại (bài viết)
        UserDAO dao = new UserDAO();
        dao.deleteUser(id);
        response.sendRedirect("admin/users");
    }
}