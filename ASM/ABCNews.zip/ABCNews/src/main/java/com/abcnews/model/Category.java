package com.abcnews.model;

public class Category {
    private String id;
    private String name;

    // Constructor rỗng
    public Category() {
    }

    // Constructor đầy đủ tham số
    public Category(String id, String name) {
        this.id = id;
        this.name = name;
    }

    // Getter và Setter 
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name;}
}